HARINFOOD LAUNCHER v1.3 (Android)
=================================
HALAMAN UTAMA (bersih, tanpa tombol)
- Tekan lama area kosong > Tambah aplikasi / Tambah widget / Ganti background / Hapus widget.
- Header warna sama dengan status bar Android. Ketuk = buka https://harinfood.mra.my.id/
- Logo header bercahaya + kilau menyapu tiap ~4 detik (hanya saat launcher terlihat, hemat baterai).

DOCK (5 slot, semuanya bisa diganti termasuk HARINFOOD POS)
- Tekan lama ikon > Ganti aplikasi / Kosongkan. Slot kosong (+) diketuk untuk memilih.

SEMUA APLIKASI
- Geser dari bawah ke atas. Tekan lama aplikasi: Taruh di halaman utama / Pasang di dock / Info / Copot.

Tombol tanpa bayangan dan riak; hanya animasi mengecil-membal saat ditekan.
Update dari v1.1 / v1.2: langsung pasang menimpa.


Pembaruan 1.4.1 (stabilitas)
- Header lebih ringkas dengan sudut bawah membulat dan tetap terlihat saat laci aplikasi dibuka.
- Header tetap dapat diketuk untuk membuka HARINFOOD POS.
- Kalender bulanan transparan dengan nama hari Bahasa Indonesia.
- Aplikasi halaman utama dapat diatur dengan drag-and-drop.
- Widget memiliki pegangan untuk drag/reorder.
- Petunjuk teks “Geser ke atas untuk semua aplikasi” dihapus, tetapi gesture swipe-up tetap aktif.
- Laci aplikasi mendapat animasi staggered scale/fade yang lebih elegan.
- Penanganan widget dibuat defensif agar widget rusak/tidak tersedia tidak membuat launcher crash.
- Ukuran minimum widget dikonversi dari dp ke px dengan benar.
- APK release menggunakan signing key proyek agar pemasangan pembaruan konsisten.
- Gesture disentuh secara aman saat lifecycle launcher belum selesai diinisialisasi.
