package com.harinfood.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Kalender bulanan ringkas dengan label hari berbahasa Indonesia. */
class CalendarPanel(context: Context) : LinearLayout(context) {
    private val title = TextView(context)
    private val grid = LinearLayout(context)
    private val idLocale = Locale("id", "ID")

    init {
        orientation = VERTICAL
        setPadding(dp(14), dp(9), dp(14), dp(10))
        background = rounded(Color.argb(112, 255, 255, 255), dp(18))

        title.setTextColor(Color.WHITE)
        title.textSize = 14f
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        addView(title, LinearLayout.LayoutParams.MATCH_PARENT, dp(28))

        grid.orientation = VERTICAL
        addView(grid, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        render(Calendar.getInstance())
    }

    fun refresh() = render(Calendar.getInstance())

    private fun render(now: Calendar) {
        grid.removeAllViews()
        val month = now.clone() as Calendar
        month.set(Calendar.DAY_OF_MONTH, 1)
        val monthTitle = SimpleDateFormat("MMMM yyyy", idLocale).format(month.time)
        title.text = monthTitle.replaceFirstChar { it.titlecase(idLocale) }

        val header = LinearLayout(context).apply { orientation = HORIZONTAL }
        listOf("Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab").forEach { day ->
            val v = dayCell(day, false)
            header.addView(v, LinearLayout.LayoutParams(0, dp(24), 1f))
        }
        grid.addView(header)

        val firstDay = month.get(Calendar.DAY_OF_WEEK) - 1 // Minggu = 0
        val maxDay = month.getActualMaximum(Calendar.DAY_OF_MONTH)
        val today = now.get(Calendar.DAY_OF_MONTH)
        val sameMonth = now.get(Calendar.MONTH) == month.get(Calendar.MONTH) &&
            now.get(Calendar.YEAR) == month.get(Calendar.YEAR)

        var day = 1
        for (row in 0 until 6) {
            val line = LinearLayout(context).apply { orientation = HORIZONTAL }
            for (col in 0 until 7) {
                val index = row * 7 + col
                if (index < firstDay || day > maxDay) {
                    line.addView(dayCell("", false), LinearLayout.LayoutParams(0, dp(28), 1f))
                } else {
                    val current = day
                    line.addView(dayCell(current.toString(), sameMonth && current == today), LinearLayout.LayoutParams(0, dp(28), 1f))
                    day++
                }
            }
            grid.addView(line)
        }
    }

    private fun dayCell(text: String, today: Boolean): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = if (text.length > 2) 10f else 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = if (today) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            if (today) background = rounded(Color.argb(190, 239, 79, 46), dp(10))
        }
    }

    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
