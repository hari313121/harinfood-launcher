package com.harinfood.launcher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.Editable
import android.text.TextWatcher
import android.view.DragEvent
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    companion object {
        const val POS_URL = "https://harinfood.mra.my.id/"
        private const val DOCK_SLOTS = 5
        private const val HOST_ID = 1024
        private const val REQ_BIND = 101
        private const val REQ_CONFIGURE = 102

        // Aplikasi populer: muncul paling atas di daftar pilihan
        private val POPULAR = listOf(
            "com.whatsapp", "com.whatsapp.w4b", "com.instagram.android", "com.facebook.katana",
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.google.android.youtube",
            "com.android.chrome", "org.telegram.messenger", "com.google.android.apps.maps",
            "com.shopee.id", "com.tokopedia.tkpd", "com.gojek.app", "com.grabtaxi.passenger",
            "id.dana", "com.spotify.music", "com.twitter.android", "com.google.android.gm",
            "com.google.android.apps.photos", "com.android.vending"
        )

        // Pilihan background bawaan (gradasi)
        private val BG_NAMES = arrayOf("Harinfood Oranye", "Sunset", "Ocean", "Forest", "Malam", "Ungu")
        private val BG_COLORS = arrayOf(
            intArrayOf(0xFFF97316.toInt(), 0xFFEF4F2E.toInt(), 0xFF7C2D12.toInt()),
            intArrayOf(0xFFF59E0B.toInt(), 0xFFDB2777.toInt(), 0xFF4C1D95.toInt()),
            intArrayOf(0xFF38BDF8.toInt(), 0xFF2563EB.toInt(), 0xFF1E1B4B.toInt()),
            intArrayOf(0xFF34D399.toInt(), 0xFF059669.toInt(), 0xFF064E3B.toInt()),
            intArrayOf(0xFF374151.toInt(), 0xFF111827.toInt(), 0xFF000000.toInt()),
            intArrayOf(0xFFA78BFA.toInt(), 0xFF6D28D9.toInt(), 0xFF312E81.toInt())
        )
    }

    private var allApps: List<AppItem> = emptyList()
    private lateinit var adapter: AppAdapter
    private lateinit var homeAdapter: AppAdapter
    private lateinit var search: EditText
    private lateinit var grid: RecyclerView
    private lateinit var homeGrid: RecyclerView
    private lateinit var homeContent: View
    private lateinit var homeScroll: NestedScrollView
    private lateinit var widgetContainer: LinearLayout
    private lateinit var calendarPanel: CalendarPanel
    private lateinit var prefs: SharedPreferences
    private lateinit var dockViews: List<ImageView>
    private lateinit var sheet: BottomSheetBehavior<View>
    private lateinit var gestures: GestureDetector
    private lateinit var widgetManager: AppWidgetManager
    private lateinit var widgetHost: AppWidgetHost

    private val dockSlots = MutableList<String?>(DOCK_SLOTS) { null }
    private val homeFlat = mutableListOf<String>()
    private val widgetIds = mutableListOf<Int>()
    private val uiHandler = Handler(Looper.getMainLooper())
    private val glowCycle = object : Runnable {
        override fun run() {
            playHeaderGlow()
            uiHandler.postDelayed(this, 4200)
        }
    }
    private var pendingWidgetId = -1
    private var pendingProvider: AppWidgetProviderInfo? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveBackground(uri)
    }

    // Daftar aplikasi dimuat ulang otomatis saat ada aplikasi dipasang / dicopot / diperbarui
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("hf_launcher", MODE_PRIVATE)

        search = findViewById(R.id.search)
        grid = findViewById(R.id.app_grid)
        homeGrid = findViewById(R.id.home_grid)
        homeContent = findViewById(R.id.home_content)
        homeScroll = findViewById(R.id.home_scroll)
        widgetContainer = findViewById(R.id.widget_container)
        calendarPanel = findViewById(R.id.calendar_panel)

        widgetManager = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, HOST_ID)
        setupWidgetDragTarget()

        setupDrawer()
        setupGrids()
        setupHeader()
        setupDock()

        applyBackground()
        loadHomeFlat()
        restoreWidgets()
        loadApps()

        // Geser dari bawah ke atas (mulai dari 1/3 layar bagian bawah) membuka semua aplikasi
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) {
                if (isEmptyHomeArea(e.rawX, e.rawY)) {
                    homeScroll.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    showHomeMenu()
                }
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null || sheet.state != BottomSheetBehavior.STATE_HIDDEN) return false
                val dy = e1.y - e2.y
                val h = window.decorView.height
                if (dy > dp(70f) && velocityY < -900f && e1.y > h * 0.62f && Math.abs(e1.x - e2.x) < dy) {
                    openDrawer()
                    return true
                }
                return false
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
    }

    // Widget hanya diperbarui saat launcher terlihat (hemat baterai)
    override fun onStart() {
        super.onStart()
        try {
            widgetHost.startListening()
        } catch (_: Exception) {
        }
        // Animasi header berjalan berkala hanya saat launcher terlihat (nol biaya saat di aplikasi lain)
        if (::calendarPanel.isInitialized) calendarPanel.refresh()
        uiHandler.removeCallbacks(glowCycle)
        uiHandler.postDelayed(glowCycle, 500)
    }

    override fun onStop() {
        super.onStop()
        try {
            widgetHost.stopListening()
        } catch (_: Exception) {
        }
        uiHandler.removeCallbacks(glowCycle)
        findViewById<View>(R.id.logo_glow).animate().cancel()
        findViewById<View>(R.id.logo_shine).animate().cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(glowCycle)
        try {
            unregisterReceiver(packageReceiver)
        } catch (_: Exception) {
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::gestures.isInitialized) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // Tombol Home ditekan saat launcher sudah terbuka: tutup laci & kembali ke atas
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            closeDrawer()
            homeScroll.smoothScrollTo(0, 0)
        }
    }

    // Launcher tidak boleh "keluar" saat Back ditekan
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (::sheet.isInitialized && sheet.state != BottomSheetBehavior.STATE_HIDDEN) {
            closeDrawer()
        } else if (::search.isInitialized && search.text.isNotEmpty()) {
            search.setText("")
            search.clearFocus()
            hideKeyboard()
        }
    }

    // ---------- Helper ----------

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()

    private fun posIcon(sizeDp: Int): Drawable {
        val src = ContextCompat.getDrawable(this, R.drawable.logo_harinfood)!!
        return IconRenderer.render(this, src, dp(sizeDp.toFloat()), fullBleed = true)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun openPos() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(POS_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("Tidak bisa membuka HARINFOOD POS")
        }
    }

    // ---------- Setup tampilan ----------

    private fun setupDrawer() {
        val drawer = findViewById<View>(R.id.drawer)
        sheet = BottomSheetBehavior.from(drawer)
        sheet.isHideable = true
        sheet.skipCollapsed = true
        sheet.peekHeight = 0
        sheet.state = BottomSheetBehavior.STATE_HIDDEN
        sheet.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                if (newState == BottomSheetBehavior.STATE_HIDDEN) {
                    search.setText("")
                    search.clearFocus()
                    hideKeyboard()
                    grid.scrollToPosition(0)
                } else if (newState == BottomSheetBehavior.STATE_EXPANDED) {
                    animateDrawerApps()
                }
            }

            override fun onSlide(bottomSheet: View, slideOffset: Float) {
                val p = slideOffset.coerceIn(0f, 1f)
                bottomSheet.scaleX = 0.985f + 0.015f * p
            }
        })
        findViewById<View>(R.id.drawer_handle).setOnClickListener { openDrawer() }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        // Tekan tombol cari di keyboard: kalau hasilnya tinggal satu, langsung dibuka
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val result = filtered()
                if (result.size == 1) launchApp(result[0])
                hideKeyboard()
                true
            } else false
        }
    }

    private fun openDrawer() {
        sheet.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun animateDrawerApps() {
        grid.post {
            for (i in 0 until grid.childCount) {
                val child = grid.getChildAt(i)
                child.animate().cancel()
                child.alpha = 0f
                child.scaleX = 0.82f
                child.scaleY = 0.82f
                child.translationY = dp(34f).toFloat()
                child.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                    .setStartDelay(i.coerceAtMost(14) * 28L).setDuration(430)
                    .setInterpolator(OvershootInterpolator(1.15f)).start()
            }
        }
    }

    private fun closeDrawer() {
        if (sheet.state != BottomSheetBehavior.STATE_HIDDEN) sheet.state = BottomSheetBehavior.STATE_HIDDEN
    }

    private fun setupGrids() {
        // Laci semua aplikasi: jumlah kolom menyesuaikan lebar layar (HP biasa = 5)
        adapter = AppAdapter(
            onClick = { launchApp(it) },
            onLongClick = { anchor, item -> showDrawerAppMenu(anchor, item) }
        )
        val span = (resources.configuration.screenWidthDp / 80).coerceIn(4, 6)
        grid.layoutManager = GridLayoutManager(this, span)
        grid.adapter = adapter
        grid.setHasFixedSize(true)

        // Aplikasi pilihan di halaman utama: 4 kolom, ikon lebih besar
        homeAdapter = AppAdapter(
            onClick = { launchApp(it) },
            onLongClick = { anchor, item -> showHomeAppMenu(anchor, item) },
            layoutId = R.layout.item_home_app
        )
        homeGrid.layoutManager = GridLayoutManager(this, 4)
        homeGrid.adapter = homeAdapter
        homeGrid.isNestedScrollingEnabled = false
        setupHomeDrag()
    }

    private fun setupHomeDrag() {
        val dragCallback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                homeAdapter.moveItem(viewHolder.bindingAdapterPosition, target.bindingAdapterPosition)
                return true
            }
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) = Unit
            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                viewHolder.itemView.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                saveHomeOrderFromAdapter()
            }
            override fun onSelectedChanged(viewHolder: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(viewHolder, actionState)
                if (actionState == ItemTouchHelper.ACTION_STATE_DRAG && viewHolder != null) {
                    viewHolder.itemView.animate().scaleX(1.06f).scaleY(1.06f).setDuration(120).start()
                    viewHolder.itemView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                }
            }
        }
        ItemTouchHelper(dragCallback).attachToRecyclerView(homeGrid)
    }

    private fun setupHeader() {
        val header = findViewById<View>(R.id.header)
        val logo = findViewById<ImageView>(R.id.logo_img)
        val box = findViewById<View>(R.id.logo_box)
        logo.setImageDrawable(posIcon(56))
        box.outlineProvider = RoundOutline
        box.clipToOutline = true

        // Tekan: header mengecil sedikit lalu membal; logo ikut "pop"
        header.pressAnim(0.97f)
        header.setOnClickListener {
            box.animate().scaleX(1.15f).scaleY(1.15f).setDuration(110).withEndAction {
                box.animate().scaleX(1f).scaleY(1f).setDuration(170).start()
            }.start()
            openPos()
        }
    }

    // Cahaya lembut berdenyut + kilau menyapu logo, sekali tiap ~4 detik (di antaranya diam = hemat baterai)
    private fun playHeaderGlow() {
        val glow = findViewById<View>(R.id.logo_glow)
        val shine = findViewById<View>(R.id.logo_shine)

        glow.animate().cancel()
        glow.animate().alpha(0.95f).scaleX(1.2f).scaleY(1.2f).setDuration(650).setStartDelay(0)
            .withEndAction {
                glow.animate().alpha(0.3f).scaleX(1f).scaleY(1f).setDuration(900).setStartDelay(0).start()
            }.start()

        shine.animate().cancel()
        shine.translationX = -dp(40f).toFloat()
        shine.animate().translationX(dp(64f).toFloat()).setDuration(850).setStartDelay(250).start()
    }

    private fun setupDock() {
        dockViews = listOf(R.id.dock_pos, R.id.dock_1, R.id.dock_2, R.id.dock_3, R.id.dock_4)
            .map { findViewById<ImageView>(it) }
        dockViews.forEach { it.pressAnim(0.9f) }
    }

    // Titik sentuh (koordinat layar) berada di dalam view?
    private fun isInside(v: View, x: Float, y: Float): Boolean {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return x >= loc[0] && x <= loc[0] + v.width && y >= loc[1] && y <= loc[1] + v.height
    }

    // Tekan lama di area KOSONG halaman utama (bukan di ikon/widget) -> menu halaman
    private fun isEmptyHomeArea(x: Float, y: Float): Boolean {
        if (sheet.state != BottomSheetBehavior.STATE_HIDDEN) return false
        if (!isInside(homeScroll, x, y)) return false
        for (i in 0 until homeGrid.childCount) if (isInside(homeGrid.getChildAt(i), x, y)) return false
        for (i in 0 until widgetContainer.childCount) if (isInside(widgetContainer.getChildAt(i), x, y)) return false
        return true
    }

    // ---------- Background halaman utama ----------

    private fun presetDrawable(i: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, BG_COLORS[i.coerceIn(0, BG_COLORS.size - 1)])

    private fun applyBackground() {
        val img = findViewById<ImageView>(R.id.bg_image)
        val scrim = findViewById<View>(R.id.bg_scrim)
        val mode = prefs.getString("bg", "preset:0") ?: "preset:0"
        when {
            mode == "photo" -> {
                val f = File(filesDir, "bg.jpg")
                val bmp = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
                if (bmp != null) {
                    img.setImageBitmap(bmp)
                    scrim.visibility = View.VISIBLE
                } else {
                    img.setImageDrawable(presetDrawable(0))
                    scrim.visibility = View.GONE
                }
            }
            mode == "wallpaper" -> {
                img.setImageDrawable(null) // wallpaper HP terlihat di belakang
                scrim.visibility = View.VISIBLE
            }
            else -> {
                val idx = mode.removePrefix("preset:").toIntOrNull() ?: 0
                img.setImageDrawable(presetDrawable(idx))
                scrim.visibility = View.GONE
            }
        }
    }

    private fun showBackgroundMenu() {
        val labels = BG_NAMES.toMutableList()
        labels += "Foto dari galeri..."
        labels += "Wallpaper HP"
        AlertDialog.Builder(this)
            .setTitle("Ganti background")
            .setItems(labels.toTypedArray()) { _, which ->
                when {
                    which < BG_NAMES.size -> {
                        prefs.edit().putString("bg", "preset:$which").apply()
                        applyBackground()
                    }
                    which == BG_NAMES.size -> pickImage.launch("image/*")
                    else -> {
                        prefs.edit().putString("bg", "wallpaper").apply()
                        applyBackground()
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun decodeScaled(uri: Uri): Bitmap? {
        val maxSide = 1920
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val src = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    val scale = maxSide.toFloat() / maxOf(w, h)
                    if (scale < 1f) decoder.setTargetSize((w * scale).toInt(), (h * scale).toInt())
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
            } else {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun saveBackground(uri: Uri) {
        thread {
            val bmp = decodeScaled(uri)
            if (bmp == null) {
                runOnUiThread { toast("Foto tidak bisa dibuka") }
                return@thread
            }
            try {
                FileOutputStream(File(filesDir, "bg.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                prefs.edit().putString("bg", "photo").apply()
                runOnUiThread { applyBackground() }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal menyimpan foto") }
            }
        }
    }

    // ---------- Menu Atur halaman ----------

    private fun showHomeMenu() {
        val labels = mutableListOf("Tambah aplikasi", "Tambah widget", "Ganti background")
        if (widgetIds.isNotEmpty()) labels += "Hapus widget"
        AlertDialog.Builder(this)
            .setTitle("Halaman utama")
            .setItems(labels.toTypedArray()) { _, which ->
                when (which) {
                    0 -> pickApp("Tambah ke halaman utama", includePos = true) { setHomeApp(it) }
                    1 -> pickWidget()
                    2 -> showBackgroundMenu()
                    3 -> removeWidgetDialog()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- Aplikasi pilihan di halaman utama ----------

    private fun loadHomeFlat() {
        homeFlat.clear()
        val raw = prefs.getString("home", "") ?: ""
        raw.split("|").filter { it.isNotBlank() }.forEach { homeFlat += it }
    }

    private fun saveHomeFlat() {
        prefs.edit().putString("home", homeFlat.joinToString("|")).apply()
    }

    private fun refreshHome() {
        val items = homeFlat.mapNotNull { key -> itemForKey(key) }
        homeAdapter.submit(items)
        homeGrid.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun saveHomeOrderFromAdapter() {
        val reordered = mutableListOf<String>()
        for (i in 0 until homeAdapter.itemCount) {
            homeAdapter.itemAt(i)?.let { item -> keyOf(item)?.let(reordered::add) }
        }
        homeFlat.clear()
        homeFlat.addAll(reordered)
        saveHomeFlat()
    }

    private fun keyOf(item: AppItem): String? =
        if (item.isPos) "pos" else item.component?.flattenToString()

    private fun itemForKey(key: String): AppItem? =
        if (key == "pos") allApps.firstOrNull { it.isPos }
        else allApps.firstOrNull { it.component?.flattenToString() == key }

    private fun setHomeApp(item: AppItem) {
        val flat = keyOf(item) ?: return
        if (!homeFlat.contains(flat)) homeFlat += flat
        saveHomeFlat()
        refreshHome()
    }

    private fun removeHomeApp(item: AppItem) {
        homeFlat.remove(keyOf(item))
        saveHomeFlat()
        refreshHome()
    }

    private fun showHomeAppMenu(anchor: View, item: AppItem) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "Lepas dari halaman utama")
        if (!item.isPos) {
            menu.menu.add(0, 2, 1, "Info aplikasi")
            menu.menu.add(0, 3, 2, "Copot pemasangan")
        }
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> removeHomeApp(item)
                2 -> openAppInfo(item)
                3 -> uninstallApp(item)
            }
            true
        }
        menu.show()
    }

    private fun openAppInfo(item: AppItem) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.packageName}")))
        } catch (e: Exception) {
            toast("Tidak bisa membuka menu ini")
        }
    }

    private fun uninstallApp(item: AppItem) {
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${item.packageName}")))
        } catch (e: Exception) {
            toast("Tidak bisa membuka menu ini")
        }
    }

    // ---------- Widget ----------

    private fun restoreWidgets() {
        val raw = prefs.getString("widgets", "") ?: ""
        raw.split(",").mapNotNull { it.trim().toIntOrNull() }.forEach { id ->
            if (!widgetIds.contains(id)) {
                try {
                    widgetIds += id
                    addWidgetView(id)
                } catch (_: Exception) {
                    widgetIds.remove(id)
                    try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {}
                }
            }
        }
        saveWidgets()
    }

    private fun saveWidgets() {
        prefs.edit().putString("widgets", widgetIds.joinToString(",")).apply()
    }

    private fun addWidgetView(id: Int) {
        try {
            val info = widgetManager.getAppWidgetInfo(id)
            if (info == null) {
                // Aplikasi widget sudah dicopot
                widgetIds.remove(id)
                saveWidgets()
                try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {}
                return
            }
            val hv = widgetHost.createView(this, id, info)
            hv.setAppWidget(id, info)
            val density = resources.displayMetrics.density
            // AppWidgetProviderInfo dimensions are expressed in dp, while LayoutParams use px.
            val hPx = (info.minHeight.toFloat() * density).toInt().coerceAtLeast(dp(72f))

        val wrapper = FrameLayout(this).apply {
            tag = id
            setPadding(dp(2f), 0, dp(2f), dp(2f))
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, hPx + dp(2f))
        lp.bottomMargin = dp(8f)
        wrapper.addView(hv, FrameLayout.LayoutParams.MATCH_PARENT, hPx)

        val handle = TextView(this).apply {
            text = "⋮"
            textSize = 18f
            gravity = android.view.Gravity.CENTER
            setTextColor(0xCCFFFFFF.toInt())
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_badge)
            elevation = dp(3f).toFloat()
            contentDescription = "Geser widget"
            setOnLongClickListener { startWidgetDrag(wrapper); true }
        }
        val handleLp = FrameLayout.LayoutParams(dp(28f), dp(28f), android.view.Gravity.END or android.view.Gravity.TOP)
        handleLp.topMargin = dp(7f)
        handleLp.marginEnd = dp(7f)
        wrapper.addView(handle, handleLp)

            widgetContainer.addView(wrapper, lp)
            hv.post {
                val wDp = (hv.width / density).toInt()
                val hDp = (hPx / density).toInt()
                try { hv.updateAppWidgetSize(null, wDp, hDp, wDp, hDp) } catch (_: Exception) {}
            }
            refreshHome()
        } catch (_: Exception) {
            widgetIds.remove(id)
            saveWidgets()
            try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {}
        }
    }

    private fun startWidgetDrag(wrapper: View) {
        val clip = android.content.ClipData.newPlainText("widget", wrapper.tag.toString())
        val shadow = View.DragShadowBuilder(wrapper)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) wrapper.startDragAndDrop(clip, shadow, wrapper, 0)
        else { @Suppress("DEPRECATION") val ignored = wrapper.startDrag(clip, shadow, wrapper, 0) }
        wrapper.alpha = 0.75f
        wrapper.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun setupWidgetDragTarget() {
        widgetContainer.setOnDragListener { _, event ->
            val dragged = event.localState as? View
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> dragged != null
                DragEvent.ACTION_DRAG_LOCATION -> {
                    if (dragged != null) {
                        val y = event.y.toInt()
                        var target = widgetContainer.childCount - 1
                        for (i in 0 until widgetContainer.childCount) {
                            val child = widgetContainer.getChildAt(i)
                            if (child !== dragged && y < child.top + child.height / 2) { target = i; break }
                        }
                        val from = widgetContainer.indexOfChild(dragged)
                        if (from >= 0 && target >= 0 && from != target) {
                            widgetContainer.removeViewAt(from)
                            widgetContainer.addView(dragged, target.coerceIn(0, widgetContainer.childCount))
                            saveWidgetViewOrder()
                        }
                    }
                    true
                }
                DragEvent.ACTION_DROP -> true
                DragEvent.ACTION_DRAG_ENDED -> { dragged?.alpha = 1f; true }
                else -> true
            }
        }
    }

    private fun saveWidgetViewOrder() {
        val order = mutableListOf<Int>()
        for (i in 0 until widgetContainer.childCount) (widgetContainer.getChildAt(i).tag as? Int)?.let(order::add)
        widgetIds.clear(); widgetIds.addAll(order); saveWidgets()
    }

    private fun pickWidget() {
        val pm = packageManager
        val providers = widgetManager.installedProviders
            .sortedBy { it.loadLabel(pm)?.lowercase() ?: "" }
        if (providers.isEmpty()) {
            toast("Tidak ada widget yang tersedia")
            return
        }
        val entries = providers.map { p ->
            val appLabel = try {
                pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString()
            } catch (e: Exception) {
                p.provider.packageName
            }
            val raw = widgetIcon(p)
            AppItem(
                label = "${p.loadLabel(pm)}  \u2022  $appLabel",
                packageName = p.provider.packageName,
                component = p.provider,
                icon = IconRenderer.render(this, raw, dp(40f))
            )
        }
        AlertDialog.Builder(this)
            .setTitle("Pilih widget")
            .setAdapter(PickerAdapter(this, entries)) { _, which -> startAddWidget(providers[which]) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun widgetIcon(p: AppWidgetProviderInfo): Drawable {
        val fromWidget: Drawable? = try {
            p.loadIcon(this, resources.displayMetrics.densityDpi)
        } catch (e: Exception) {
            null
        }
        if (fromWidget != null) return fromWidget
        return try {
            packageManager.getApplicationIcon(p.provider.packageName)
        } catch (e: Exception) {
            ContextCompat.getDrawable(this, R.drawable.ic_plus)!!
        }
    }

    @Suppress("DEPRECATION")
    private fun startAddWidget(p: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        if (widgetManager.bindAppWidgetIdIfAllowed(id, p.provider)) {
            configureOrFinish(id, p)
        } else {
            pendingWidgetId = id
            pendingProvider = p
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            }
            try {
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                widgetHost.deleteAppWidgetId(id)
                toast("Widget tidak bisa ditambahkan")
            }
        }
    }

    private fun configureOrFinish(id: Int, p: AppWidgetProviderInfo) {
        if (p.configure != null) {
            pendingWidgetId = id
            pendingProvider = p
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIGURE, null)
            } catch (e: Exception) {
                finishAddWidget(id)
            }
        } else {
            finishAddWidget(id)
        }
    }

    private fun finishAddWidget(id: Int) {
        widgetIds += id
        saveWidgets()
        addWidgetView(id)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingWidgetId
        when (requestCode) {
            REQ_BIND -> {
                val p = pendingProvider
                if (resultCode == RESULT_OK && p != null && id != -1) {
                    configureOrFinish(id, p)
                } else if (id != -1) {
                    widgetHost.deleteAppWidgetId(id)
                }
            }
            REQ_CONFIGURE -> {
                if (resultCode == RESULT_OK && id != -1) {
                    finishAddWidget(id)
                } else if (id != -1) {
                    widgetHost.deleteAppWidgetId(id)
                }
            }
        }
        if (requestCode == REQ_BIND || requestCode == REQ_CONFIGURE) {
            pendingWidgetId = -1
            pendingProvider = null
        }
    }

    private fun removeWidgetDialog() {
        val pm = packageManager
        val ids = widgetIds.toList()
        val labels = ids.map { id ->
            widgetManager.getAppWidgetInfo(id)?.loadLabel(pm)?.toString() ?: "Widget $id"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Hapus widget")
            .setItems(labels) { _, which ->
                val id = ids[which]
                widgetIds.remove(id)
                saveWidgets()
                widgetHost.deleteAppWidgetId(id)
                for (i in widgetContainer.childCount - 1 downTo 0) {
                    if (widgetContainer.getChildAt(i).tag == id) widgetContainer.removeViewAt(i)
                }
                refreshHome()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- Daftar aplikasi ----------

    private fun loadApps() {
        thread {
            val pm = packageManager
            val iconPx = dp(52f)
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppItem(
                        label = it.loadLabel(pm).toString(),
                        packageName = it.activityInfo.packageName,
                        component = ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                        icon = IconRenderer.render(this, it.loadIcon(pm), iconPx)
                    )
                }
                .sortedBy { it.label.lowercase() }
            val pos = AppItem(
                label = "HARINFOOD POS",
                packageName = "",
                component = null,
                icon = posIcon(52),
                isPos = true
            )
            val list = listOf(pos) + apps
            runOnUiThread {
                allApps = list
                ensureDockDefaults(apps)
                loadDockSlots()
                refreshDock()
                refreshHome()
                applyFilter()
            }
        }
    }

    private fun filtered(): List<AppItem> {
        val q = search.text.toString().trim()
        return if (q.isEmpty()) allApps else allApps.filter { it.label.contains(q, ignoreCase = true) }
    }

    private fun applyFilter() {
        adapter.submit(filtered())
    }

    private fun launchApp(item: AppItem) {
        if (item.isPos || item.component == null) {
            openPos()
            closeDrawer()
            return
        }
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = item.component
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        try {
            startActivity(intent)
            closeDrawer()
        } catch (e: Exception) {
            toast("Aplikasi tidak bisa dibuka")
        }
    }

    private fun showDrawerAppMenu(anchor: View, item: AppItem) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "Taruh di halaman utama")
        menu.menu.add(0, 2, 1, "Pasang di dock")
        if (!item.isPos) {
            menu.menu.add(0, 3, 2, "Info aplikasi")
            menu.menu.add(0, 4, 3, "Copot pemasangan")
        }
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> {
                    setHomeApp(item)
                    toast("Ditambahkan ke halaman utama")
                }
                2 -> chooseSlotFor(item)
                3 -> openAppInfo(item)
                4 -> uninstallApp(item)
            }
            true
        }
        menu.show()
    }

    // ---------- Dock (bisa diganti aplikasi populer) ----------
    // Slot paling kiri = HARINFOOD POS (tetap). 4 slot lain bebas diganti.

    private fun ensureDockDefaults(apps: List<AppItem>) {
        if (prefs.contains("dock2")) return
        val slots = mutableListOf("pos")
        val old = prefs.getString("dock", null)
        if (old != null) {
            // Migrasi dari versi sebelumnya (4 slot): POS tetap di slot pertama
            old.split("|").take(4).forEach { slots += if (it.isBlank()) "-" else it }
        } else {
            val dialer = try {
                (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage
            } catch (e: Exception) {
                null
            }
            val order = listOfNotNull(dialer) + listOf(
                "com.whatsapp", "com.android.chrome", "com.instagram.android",
                "com.google.android.youtube", "com.facebook.katana", "com.google.android.apps.photos"
            )
            for (p in order) {
                val a = apps.firstOrNull { it.packageName == p } ?: continue
                val flat = a.component!!.flattenToString()
                if (slots.size < DOCK_SLOTS && !slots.contains(flat)) slots += flat
            }
        }
        while (slots.size < DOCK_SLOTS) slots += "-"
        prefs.edit().putString("dock2", slots.take(DOCK_SLOTS).joinToString("|")).apply()
    }

    private fun loadDockSlots() {
        val parts = (prefs.getString("dock2", "") ?: "").split("|")
        for (i in 0 until DOCK_SLOTS) {
            val s = parts.getOrNull(i)
            dockSlots[i] = if (s.isNullOrBlank() || s == "-") null else s
        }
    }

    private fun saveDockSlots() {
        prefs.edit().putString("dock2", dockSlots.joinToString("|") { it ?: "-" }).apply()
    }

    private fun itemForSlot(i: Int): AppItem? {
        val key = dockSlots[i] ?: return null
        return itemForKey(key)
    }

    private fun refreshDock() {
        dockViews.forEachIndexed { i, v ->
            val item = itemForSlot(i)
            if (item != null) {
                v.setImageDrawable(item.icon)
                v.contentDescription = item.label
                v.setOnClickListener { launchApp(item) }
                v.setOnLongClickListener {
                    showDockMenu(v, i)
                    true
                }
            } else {
                v.setImageResource(R.drawable.ic_add_slot)
                v.contentDescription = "Tambah aplikasi"
                v.setOnClickListener { pickApp("Pilih aplikasi untuk dock", includePos = true) { app -> setSlot(i, app) } }
                v.setOnLongClickListener(null)
            }
        }
    }

    private fun showDockMenu(anchor: View, slot: Int) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "Ganti aplikasi")
        menu.menu.add(0, 2, 1, "Kosongkan")
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> pickApp("Pilih aplikasi untuk dock", includePos = true) { app -> setSlot(slot, app) }
                2 -> {
                    dockSlots[slot] = null
                    saveDockSlots()
                    refreshDock()
                }
            }
            true
        }
        menu.show()
    }

    private fun setSlot(slot: Int, item: AppItem) {
        val flat = keyOf(item) ?: return
        for (i in 0 until DOCK_SLOTS) if (dockSlots[i] == flat) dockSlots[i] = null
        dockSlots[slot] = flat
        saveDockSlots()
        refreshDock()
    }

    private fun chooseSlotFor(item: AppItem) {
        val labels = Array(DOCK_SLOTS) { "Slot ${it + 1}: ${itemForSlot(it)?.label ?: "kosong"}" }
        AlertDialog.Builder(this)
            .setTitle("Pasang di slot dock")
            .setItems(labels) { _, which -> setSlot(which, item) }
            .setNegativeButton("Batal", null)
            .show()
    }

    // Dialog pilih aplikasi (HARINFOOD POS & aplikasi populer tampil paling atas)
    private fun pickApp(title: String, includePos: Boolean = false, onPick: (AppItem) -> Unit) {
        val popularIdx = POPULAR.withIndex().associate { it.value to it.index }
        val candidates = allApps.filter { includePos || !it.isPos }.sortedWith(
            compareBy<AppItem>(
                { if (it.isPos) -1 else (popularIdx[it.packageName] ?: Int.MAX_VALUE) },
                { it.label.lowercase() }
            )
        )
        AlertDialog.Builder(this)
            .setTitle(title)
            .setAdapter(PickerAdapter(this, candidates)) { _, which -> onPick(candidates[which]) }
            .setNegativeButton("Batal", null)
            .show()
    }
}
