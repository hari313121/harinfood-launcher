HARINFOOD LAUNCHER v1.5 (Android) - versi ringan
================================================
KECEPATAN
- Daftar aplikasi dibaca dari catatan di disk (instan); pembaruan ke sistem jalan senyap di latar belakang.
- Ikon dibuat sekali lalu disimpan di cache; halaman utama & dock langsung tampil dari cache.
- Halaman utama tampil serempak (kalender, ikon, dock) lewat fade halus setelah siap = tidak acak-acakan.
- Laci aplikasi diisi saat menganggur; ikon laci dimuat di latar belakang dengan kotak penampung.
- Foto latar dibaca seukuran layar di latar belakang. Build dioptimasi (tanpa mode debug, R8).

TAMPILAN (tetap sama)
- Header menyatu dengan status bar, kalender, widget & aplikasi bisa digeser, dock 5 slot, laci geser dari bawah.
- Dock putih: kilau lembut menyapu berkala (sekali ~4 detik, hanya saat launcher terlihat).
- Semua animasi diperhalus (kurva ease, lapisan hardware saat laci bergerak).

Update dari versi sebelumnya: langsung pasang menimpa.
