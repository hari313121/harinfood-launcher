HARINFOOD LAUNCHER v1.1 (Android)
=================================
- Header ringkas (logo, nama kedai, jam). Ketuk header = buka https://harinfood.mra.my.id/
- Ikon aplikasi diseragamkan jadi kotak membulat modern; animasi berulang dihapus (hemat baterai).
- Dock: slot 1 = HARINFOOD POS (tetap). 4 slot lain bisa diganti:
    * tekan lama ikon di dock > Ganti aplikasi / Kosongkan
    * atau tekan lama aplikasi di daftar > Pasang di dock
    * slot kosong (tanda +) diketuk untuk memilih aplikasi; aplikasi populer tampil paling atas.
- Tekan lama aplikasi lain: Info aplikasi / Copot pemasangan.

UPDATE DARI VERSI 1.0: copot dulu launcher lama (Pengaturan > Aplikasi > Harinfood Launcher > Copot),
karena kunci tanda tangannya berbeda. Mulai versi 1.1 kunci sudah tetap, jadi update berikutnya
bisa langsung dipasang menimpa tanpa mencopot.
