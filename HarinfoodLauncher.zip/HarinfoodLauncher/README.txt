HARINFOOD LAUNCHER v1.4 (Android)
=================================
HEADER
- Ramping, warna sama dengan status bar, sudut bawah membulat. Selalu tampil (juga saat laci terbuka).
- Ketuk = buka https://harinfood.mra.my.id/. Logo bercahaya + kilau tiap ~4 detik (hanya saat launcher terlihat).

HALAMAN UTAMA (bersih, atur manual)
- Kalender satu bulan (hari Indonesia, agak transparan) sudah tersedia.
- Tekan lama area kosong: Tambah aplikasi / Tambah widget / Ganti background / Tambah kalender.
- Tekan lama sebuah benda lalu GESER untuk memindahkan (menempel ke kotak terdekat).
  Tekan lama lalu LEPAS tanpa menggeser = menu (Ubah ukuran, Hapus/Lepas, Info, Copot).

LACI SEMUA APLIKASI
- Geser dari bawah ke atas (mulai dari 1/3 layar bawah) atau ketuk garis kecil di atas dock.
- Animasi: halaman utama menjauh, ikon muncul berurutan dengan membal halus.

DOCK: 5 slot, semuanya bisa diganti (tekan lama > Ganti aplikasi / Kosongkan).
Update dari v1.1-v1.3.1: langsung pasang menimpa.
