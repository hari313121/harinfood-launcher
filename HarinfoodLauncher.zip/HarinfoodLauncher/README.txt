HARINFOOD LAUNCHER v1.3 (Android)
=================================
HALAMAN UTAMA (bersih, tanpa tombol)
- Tekan lama area kosong > Tambah aplikasi / Tambah widget / Ganti background / Hapus widget.
- Header warna sama dengan status bar Android. Ketuk = buka https://harinfood.mra.my.id/
- Logo header bercahaya + kilau menyapu tiap ~4 detik (hanya saat launcher terlihat, hemat baterai).

DOCK (5 slot, semuanya bisa diganti termasuk HARINFOOD POS)
- Tekan lama ikon > Ganti aplikasi / Kosongkan. Slot kosong (+) diketuk untuk memilih.

SEMUA APLIKASI
- Geser dari bawah ke atas. Tekan lama aplikasi: Taruh di halaman utama / Pasang di dock / Info / Copot.

Tombol tanpa bayangan dan riak; hanya animasi mengecil-membal saat ditekan.
Update dari v1.1 / v1.2: langsung pasang menimpa.
