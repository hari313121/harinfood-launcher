HARINFOOD LAUNCHER v1.2 (Android)
=================================
HALAMAN UTAMA
- Header ringkas (logo, nama kedai, jam). Ketuk header = buka https://harinfood.mra.my.id/
  (animasi ringan hanya saat disentuh, tidak ada animasi yang jalan terus = hemat baterai).
- Ketuk "+ Atur halaman" (atau tekan lama area kosong) untuk:
    * Ganti background: 6 gradasi, foto dari galeri, atau wallpaper HP
    * Tambah widget dari aplikasi lain (jam, cuaca, kalender, dll) / Hapus widget
    * Tambah aplikasi pilihan ke halaman utama
- Tekan lama aplikasi di halaman utama: Lepas / Info aplikasi / Copot.

SEMUA APLIKASI (LACI)
- Geser dari bawah ke atas (atau ketuk "Geser ke atas untuk semua aplikasi").
- Geser ke bawah / tombol Back / tombol Home untuk menutup.
- Tekan lama aplikasi: Taruh di halaman utama / Pasang di dock / Info / Copot.

DOCK
- Slot 1 = HARINFOOD POS (tetap). 4 slot lain bisa diganti (tekan lama ikon > Ganti aplikasi).

UPDATE DARI VERSI 1.1: langsung pasang menimpa (kunci tanda tangan sudah tetap).
Dari versi 1.0: copot dulu.
