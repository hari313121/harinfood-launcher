package com.harinfood.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import java.util.Calendar
import kotlin.math.min

/**
 * Kalender satu bulan (hari berbahasa Indonesia, minggu mulai Senin), latar agak transparan
 * sehingga background halaman utama tetap terlihat. Digambar langsung di canvas = ringan.
 */
class CalendarView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    View(context, attrs) {

    private val d = resources.displayMetrics.density
    private val months = arrayOf(
        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
    )
    private val dayNames = arrayOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x59000000 }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x33FFFFFF
        style = Paint.Style.STROKE
        strokeWidth = 1f * d
    }
    private val todayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF97316.toInt() }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    private fun baseline(cy: Float): Float {
        val fm = text.fontMetrics
        return cy - (fm.ascent + fm.descent) / 2f
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 18f * d
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, bg)
        rect.set(0.5f * d, 0.5f * d, w - 0.5f * d, h - 0.5f * d)
        c.drawRoundRect(rect, r, r, stroke)

        val now = Calendar.getInstance()
        val year = now.get(Calendar.YEAR)
        val month = now.get(Calendar.MONTH)
        val today = now.get(Calendar.DAY_OF_MONTH)
        val first = Calendar.getInstance().apply {
            clear()
            set(year, month, 1)
        }
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Senin = 0
        val dim = first.getActualMaximum(Calendar.DAY_OF_MONTH)
        val weeks = (offset + dim + 6) / 7

        val pad = 10f * d
        val titleH = 24f * d
        val headH = 18f * d
        val colW = (w - 2 * pad) / 7f
        val rowH = (h - 2 * pad - titleH - headH) / weeks

        // Judul bulan
        text.typeface = Typeface.DEFAULT_BOLD
        text.textSize = 13f * d
        text.textAlign = Paint.Align.LEFT
        text.color = 0xFFFFFFFF.toInt()
        c.drawText("${months[month]} $year", pad + 2f * d, baseline(pad + titleH / 2f), text)
        text.textAlign = Paint.Align.CENTER

        // Nama hari
        text.textSize = min(10f * d, headH * 0.6f)
        for (i in 0 until 7) {
            text.color = if (i == 6) 0xFFFF8A80.toInt() else 0xCCFFFFFF.toInt()
            c.drawText(dayNames[i], pad + colW * (i + 0.5f), baseline(pad + titleH + headH / 2f), text)
        }

        // Tanggal
        text.textSize = min(12f * d, rowH * 0.6f)
        for (day in 1..dim) {
            val idx = offset + day - 1
            val row = idx / 7
            val col = idx % 7
            val cx = pad + colW * (col + 0.5f)
            val cy = pad + titleH + headH + rowH * (row + 0.5f)
            if (day == today) {
                c.drawCircle(cx, cy, min(colW, rowH) * 0.46f, todayPaint)
                text.typeface = Typeface.DEFAULT_BOLD
                text.color = 0xFFFFFFFF.toInt()
            } else {
                text.typeface = Typeface.DEFAULT
                text.color = if (col == 6) 0xFFFF8A80.toInt() else 0xFFFFFFFF.toInt()
            }
            c.drawText(day.toString(), cx, baseline(cy), text)
        }
    }
}
