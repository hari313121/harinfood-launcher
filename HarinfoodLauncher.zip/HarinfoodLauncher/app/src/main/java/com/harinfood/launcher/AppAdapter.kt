package com.harinfood.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Satu aplikasi di daftar. Ikon TIDAK disimpan di sini: diambil oleh IconLoader dari cache disk
 * lewat [iconKey] (staticIcon hanya untuk entri khusus seperti daftar widget).
 */
class AppItem(
    val label: String,
    val packageName: String,
    val component: ComponentName?,
    val isPos: Boolean = false,
    val iconKey: String = "",
    val staticIcon: Drawable? = null
)

class AppAdapter(
    private val onClick: (AppItem) -> Unit,
    private val onLongClick: (View, AppItem) -> Unit,
    private val layoutId: Int = R.layout.item_app
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppItem> = emptyList()

    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.app_icon)
        val label: TextView = view.findViewById(R.id.app_label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
        val vh = VH(v)
        v.pressAnim(0.92f)
        return vh
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        IconLoader.load(holder.icon, item)
        holder.label.text = item.label
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener {
            onLongClick(it, item)
            true
        }
    }

    override fun getItemCount(): Int = items.size
}

/** Daftar pilihan aplikasi/widget (ikon + nama) untuk dialog */
class PickerAdapter(context: Context, items: List<AppItem>) :
    ArrayAdapter<AppItem>(context, 0, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_picker, parent, false)
        val item = getItem(position)!!
        IconLoader.load(v.findViewById(R.id.picker_icon), item)
        v.findViewById<TextView>(R.id.picker_label).text = item.label
        return v
    }
}
