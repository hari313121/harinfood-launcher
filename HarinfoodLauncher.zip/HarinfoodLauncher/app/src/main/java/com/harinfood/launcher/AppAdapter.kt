package com.harinfood.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class AppItem(
    val label: String,
    val packageName: String,
    val component: ComponentName?,
    val icon: Drawable,
    val isPos: Boolean = false
)

class AppAdapter(
    private val onClick: (AppItem) -> Unit,
    private val onLongClick: (View, AppItem) -> Unit,
    private val layoutId: Int = R.layout.item_app
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppItem> = emptyList()

    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.app_icon)
        val label: TextView = view.findViewById(R.id.app_label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
        val vh = VH(v)
        vh.icon.outlineProvider = RoundOutline
        vh.icon.elevation = v.resources.displayMetrics.density * 1.5f
        return vh
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.icon.setImageDrawable(item.icon)
        holder.label.text = item.label
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener {
            onLongClick(it, item)
            true
        }
    }

    override fun getItemCount(): Int = items.size
}

/** Daftar pilihan aplikasi (ikon + nama) untuk dialog penggantian dock */
class PickerAdapter(context: Context, items: List<AppItem>) :
    ArrayAdapter<AppItem>(context, 0, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_picker, parent, false)
        val item = getItem(position)!!
        v.findViewById<ImageView>(R.id.picker_icon).setImageDrawable(item.icon)
        v.findViewById<TextView>(R.id.picker_label).text = item.label
        return v
    }
}
