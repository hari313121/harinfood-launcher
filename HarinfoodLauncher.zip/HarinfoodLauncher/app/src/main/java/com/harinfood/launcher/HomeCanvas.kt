package com.harinfood.launcher

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/** Satu benda di halaman utama: aplikasi ("a"), widget ("w") atau kalender ("c") pada posisi kotak tertentu. */
class HomeItem(
    val type: String,
    val key: String,
    var col: Int,
    var row: Int,
    var w: Int = 1,
    var h: Int = 1
)

object HomeGrid {
    fun overlaps(a: HomeItem, b: HomeItem): Boolean =
        a.col < b.col + b.w && b.col < a.col + a.w && a.row < b.row + b.h && b.row < a.row + a.h

    /** Cari posisi kosong terdekat dengan (prefCol, prefRow). null = tidak ada tempat. */
    fun findSpot(
        cols: Int, rows: Int, w: Int, h: Int,
        others: List<HomeItem>, prefCol: Int, prefRow: Int
    ): Pair<Int, Int>? {
        var best: Pair<Int, Int>? = null
        var bestD = Int.MAX_VALUE
        val probe = HomeItem("x", "", 0, 0, w, h)
        for (r in 0..(rows - h)) {
            for (c in 0..(cols - w)) {
                probe.col = c
                probe.row = r
                if (others.none { overlaps(it, probe) }) {
                    val d = abs(c - prefCol) + abs(r - prefRow)
                    if (d < bestD) {
                        bestD = d
                        best = Pair(c, r)
                    }
                }
            }
        }
        return best
    }
}

/**
 * Halaman utama berbentuk kotak-kotak. Tekan lama sebuah benda lalu geser untuk memindahkan
 * (menempel ke kotak terdekat). Tekan lama lalu lepas tanpa menggeser = menu benda itu.
 * Tekan lama di area kosong = menu halaman.
 */
class HomeCanvas @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    FrameLayout(context, attrs) {

    var cols = 4
    private val density = resources.displayMetrics.density
    val cellHeight = (92 * density).toInt()
    private val inset = (3 * density).toInt()

    var onEmptyLongPress: (() -> Unit)? = null
    var onItemMenu: ((View) -> Unit)? = null
    var onItemMoved: ((View) -> Unit)? = null
    var onSized: (() -> Unit)? = null

    var isDragging = false
        private set

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private val handler = Handler(Looper.getMainLooper())
    private var downX = 0f
    private var downY = 0f
    private var pressedChild: View? = null
    private var dragView: View? = null
    private var needLift = false
    private val longPressRunnable = Runnable { onLongPressFired() }

    val cellWidth: Int get() = ((width - paddingLeft - paddingRight) / cols).coerceAtLeast(1)
    val rows: Int get() = ((height - paddingTop - paddingBottom) / cellHeight).coerceAtLeast(1)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) onSized?.invoke()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacks(longPressRunnable)
    }

    fun addItem(v: View, item: HomeItem) {
        v.tag = item
        addView(v, LayoutParams(0, 0, Gravity.TOP or Gravity.START))
        place(v)
    }

    fun place(v: View) {
        val item = v.tag as HomeItem
        val lp = v.layoutParams as LayoutParams
        lp.gravity = Gravity.TOP or Gravity.START
        lp.width = item.w * cellWidth - 2 * inset
        lp.height = item.h * cellHeight - 2 * inset
        lp.leftMargin = item.col * cellWidth + inset
        lp.topMargin = item.row * cellHeight + inset
        v.layoutParams = lp
    }

    private fun childAt(x: Float, y: Float): View? {
        for (i in childCount - 1 downTo 0) {
            val c = getChildAt(i)
            if (c.visibility != VISIBLE) continue
            val l = c.left + c.translationX
            val t = c.top + c.translationY
            if (x >= l && x <= l + c.width && y >= t && y <= t + c.height) return c
        }
        return null
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacks(longPressRunnable)
                isDragging = false
                downX = ev.x
                downY = ev.y
                pressedChild = childAt(ev.x, ev.y)
                handler.postDelayed(longPressRunnable, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDragging) {
                    handleDrag(ev)
                    return true
                }
                if (hypot(ev.x - downX, ev.y - downY) > touchSlop) handler.removeCallbacks(longPressRunnable)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                if (isDragging) {
                    finishDrag(ev, ev.actionMasked == MotionEvent.ACTION_CANCEL)
                    return true
                }
            }
        }
        return isDragging
    }

    // Dipakai saat tidak ada anak yang menerima sentuhan (area kosong) atau setelah drag dimulai
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (isDragging) handleDrag(ev)
                else if (hypot(ev.x - downX, ev.y - downY) > touchSlop) handler.removeCallbacks(longPressRunnable)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                if (isDragging) finishDrag(ev, ev.actionMasked == MotionEvent.ACTION_CANCEL)
            }
        }
        return true
    }

    private fun onLongPressFired() {
        val child = pressedChild
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        if (child == null) {
            onEmptyLongPress?.invoke()
            return
        }
        isDragging = true
        dragView = child
        needLift = true
        child.bringToFront()
        parent?.requestDisallowInterceptTouchEvent(true)
    }

    private fun handleDrag(ev: MotionEvent) {
        val v = dragView ?: return
        if (needLift) {
            // Diangkat sedikit; ditunda satu langkah agar tidak tertimpa animasi "batal" milik anak
            needLift = false
            v.post { v.animate().scaleX(1.08f).scaleY(1.08f).alpha(0.92f).setDuration(140).start() }
        }
        val tx = (ev.x - downX).coerceIn(-v.left.toFloat(), (width - v.right).toFloat().coerceAtLeast(0f))
        val ty = (ev.y - downY).coerceIn(-v.top.toFloat(), (height - v.bottom).toFloat().coerceAtLeast(0f))
        v.translationX = tx
        v.translationY = ty
    }

    private fun finishDrag(ev: MotionEvent, cancelled: Boolean) {
        val v = dragView ?: return
        val item = v.tag as HomeItem
        isDragging = false
        dragView = null
        v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(160).start()

        if (cancelled) {
            v.animate().translationX(0f).translationY(0f).setDuration(180).start()
            return
        }
        // Tidak digeser: tampilkan menu benda ini
        if (hypot(ev.x - downX, ev.y - downY) < touchSlop) {
            v.translationX = 0f
            v.translationY = 0f
            onItemMenu?.invoke(v)
            return
        }

        val visualLeft = v.left + v.translationX
        val visualTop = v.top + v.translationY
        var col = ((visualLeft - inset) / cellWidth).roundToInt()
        var row = ((visualTop - inset) / cellHeight).roundToInt()
        col = col.coerceIn(0, max(0, cols - item.w))
        row = row.coerceIn(0, max(0, rows - item.h))

        val others = (0 until childCount).map { getChildAt(it) }
            .filter { it !== v }.mapNotNull { it.tag as? HomeItem }
        val spot = HomeGrid.findSpot(cols, rows, item.w, item.h, others, col, row)
            ?: Pair(item.col, item.row)
        item.col = spot.first
        item.row = spot.second

        // Meluncur halus ke kotak tujuan, lalu kunci posisi
        val targetLeft = item.col * cellWidth + inset
        val targetTop = item.row * cellHeight + inset
        v.animate()
            .translationX((targetLeft - v.left).toFloat())
            .translationY((targetTop - v.top).toFloat())
            .setDuration(200)
            .withEndAction {
                place(v)
                v.translationX = 0f
                v.translationY = 0f
            }.start()
        onItemMoved?.invoke(v)
    }
}
