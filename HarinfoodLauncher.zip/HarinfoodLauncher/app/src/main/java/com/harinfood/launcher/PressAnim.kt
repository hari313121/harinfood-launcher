package com.harinfood.launcher

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

/**
 * Satu-satunya efek pada tombol: mengecil sedikit saat ditekan lalu membal kembali.
 * Tanpa bayangan, tanpa riak (ripple). Listener mengembalikan false sehingga klik & tekan-lama tetap jalan.
 */
@SuppressLint("ClickableViewAccessibility")
fun View.pressAnim(pressedScale: Float = 0.92f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(pressedScale).scaleY(pressedScale).setDuration(80)
                    .setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(180)
                    .setInterpolator(OvershootInterpolator(2.2f)).start()
        }
        false
    }
}
