package com.harinfood.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.view.ViewOutlineProvider

/**
 * Menyeragamkan semua ikon aplikasi menjadi kotak membulat modern (squircle).
 * - Ikon adaptive: lapisan latar + depan digambar penuh (tanpa lingkaran putih di sekelilingnya).
 * - Ikon lama: diletakkan di atas kotak putih bersih.
 * Hasilnya dirender SEKALI ke bitmap, jadi saat scroll tidak ada kerja tambahan (hemat baterai).
 */
object IconRenderer {

    const val RADIUS_RATIO = 0.30f

    fun render(context: Context, src: Drawable, size: Int, fullBleed: Boolean = false): Drawable {
        val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(content)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && src is AdaptiveIconDrawable) {
            // Area terlihat ikon adaptive = 72/108 dari kanvas, jadi lapisan diperbesar 1.5x
            val ext = (size * 0.25f).toInt()
            src.background?.let {
                it.setBounds(-ext, -ext, size + ext, size + ext)
                it.draw(c)
            }
            src.foreground?.let {
                it.setBounds(-ext, -ext, size + ext, size + ext)
                it.draw(c)
            }
        } else if (fullBleed) {
            src.setBounds(0, 0, size, size)
            src.draw(c)
        } else {
            c.drawColor(Color.WHITE)
            val pad = (size * 0.16f).toInt()
            src.setBounds(pad, pad, size - pad, size - pad)
            src.draw(c)
        }

        // Potong dengan sudut membulat yang halus (anti-alias)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val oc = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val r = size * RADIUS_RATIO
        oc.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        oc.drawBitmap(content, 0f, 0f, paint)
        content.recycle()
        return BitmapDrawable(context.resources, out)
    }
}

/** Bayangan tipis mengikuti bentuk ikon */
object RoundOutline : ViewOutlineProvider() {
    override fun getOutline(view: View, outline: Outline) {
        outline.setRoundRect(0, 0, view.width, view.height, view.width * IconRenderer.RADIUS_RATIO)
    }
}
