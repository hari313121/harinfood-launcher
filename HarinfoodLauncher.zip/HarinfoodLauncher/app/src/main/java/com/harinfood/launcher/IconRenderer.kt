package com.harinfood.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import android.view.ViewOutlineProvider

/**
 * Menyeragamkan ikon aplikasi menjadi kotak membulat modern (squircle).
 * - Ikon adaptive: lapisan latar + depan digambar penuh.
 * - Ikon lama: diletakkan di atas kotak putih bersih.
 * Memakai SATU bitmap per ikon (hemat memori); hasilnya disimpan ke disk oleh IconLoader.
 */
object IconRenderer {

    const val RADIUS_RATIO = 0.30f

    fun render(context: Context, src: Drawable, size: Int, fullBleed: Boolean = false): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && src is AdaptiveIconDrawable) {
            // Area terlihat ikon adaptive = 72/108 dari kanvas, jadi lapisan diperbesar 1.5x
            val ext = (size * 0.25f).toInt()
            src.background?.let {
                it.setBounds(-ext, -ext, size + ext, size + ext)
                it.draw(c)
            }
            src.foreground?.let {
                it.setBounds(-ext, -ext, size + ext, size + ext)
                it.draw(c)
            }
        } else if (fullBleed) {
            src.setBounds(0, 0, size, size)
            src.draw(c)
        } else {
            c.drawColor(Color.WHITE)
            val pad = (size * 0.16f).toInt()
            src.setBounds(pad, pad, size - pad, size - pad)
            src.draw(c)
        }

        // Hapus sudut di luar kotak membulat (tepi halus / anti-alias), tanpa bitmap kedua
        val r = size * RADIUS_RATIO
        val path = Path().apply {
            addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, Path.Direction.CW)
            fillType = Path.FillType.INVERSE_WINDING
        }
        val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        c.drawPath(path, clear)
        return bmp
    }
}

/** Pemotong sudut membulat untuk logo header */
object RoundOutline : ViewOutlineProvider() {
    override fun getOutline(view: View, outline: Outline) {
        outline.setRoundRect(0, 0, view.width, view.height, view.width * IconRenderer.RADIUS_RATIO)
    }
}
