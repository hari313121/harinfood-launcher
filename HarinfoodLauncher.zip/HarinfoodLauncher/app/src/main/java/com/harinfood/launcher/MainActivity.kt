package com.harinfood.launcher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread

/** Catatan ringan satu aplikasi (disimpan di apps_index.json agar pembukaan berikutnya instan). */
private data class AppEntry(val pkg: String, val cls: String, val label: String, val stamp: Long)

class MainActivity : AppCompatActivity() {

    companion object {
        const val POS_URL = "https://harinfood.mra.my.id/"
        private const val DOCK_SLOTS = 5
        private const val HOST_ID = 1024
        private const val REQ_BIND = 101
        private const val REQ_CONFIGURE = 102
        private const val COLS = 4

        // Aplikasi populer: muncul paling atas di daftar pilihan
        private val POPULAR = listOf(
            "com.whatsapp", "com.whatsapp.w4b", "com.instagram.android", "com.facebook.katana",
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.google.android.youtube",
            "com.android.chrome", "org.telegram.messenger", "com.google.android.apps.maps",
            "com.shopee.id", "com.tokopedia.tkpd", "com.gojek.app", "com.grabtaxi.passenger",
            "id.dana", "com.spotify.music", "com.twitter.android", "com.google.android.gm",
            "com.google.android.apps.photos", "com.android.vending"
        )

        // Pilihan background bawaan (gradasi). Nomor 0 sama dengan warna jendela awal (tanpa kedipan)
        private val BG_NAMES = arrayOf("Harinfood Oranye", "Sunset", "Ocean", "Forest", "Malam", "Ungu")
        private val BG_COLORS = arrayOf(
            intArrayOf(0xFFF97316.toInt(), 0xFFEF4F2E.toInt(), 0xFF7C2D12.toInt()),
            intArrayOf(0xFFF59E0B.toInt(), 0xFFDB2777.toInt(), 0xFF4C1D95.toInt()),
            intArrayOf(0xFF38BDF8.toInt(), 0xFF2563EB.toInt(), 0xFF1E1B4B.toInt()),
            intArrayOf(0xFF34D399.toInt(), 0xFF059669.toInt(), 0xFF064E3B.toInt()),
            intArrayOf(0xFF374151.toInt(), 0xFF111827.toInt(), 0xFF000000.toInt()),
            intArrayOf(0xFFA78BFA.toInt(), 0xFF6D28D9.toInt(), 0xFF312E81.toInt())
        )
    }

    private val posItem = AppItem("HARINFOOD POS", "", null, isPos = true, iconKey = "hf_pos_logo")
    private var allApps: List<AppItem> = emptyList()
    private var appEntries: List<AppEntry> = emptyList()
    private var appsLoaded = false
    private var hadIndex = false

    private lateinit var adapter: AppAdapter
    private lateinit var search: EditText
    private lateinit var grid: RecyclerView
    private lateinit var homeCanvas: HomeCanvas
    private lateinit var homeBody: View
    private lateinit var dockArea: View
    private lateinit var prefs: SharedPreferences
    private lateinit var dockViews: List<ImageView>
    private lateinit var sheet: BottomSheetBehavior<View>
    private lateinit var gestures: GestureDetector
    private lateinit var widgetManager: AppWidgetManager
    private lateinit var widgetHost: AppWidgetHost

    private val dockSlots = MutableList<String?>(DOCK_SLOTS) { null }
    private val homeItems = mutableListOf<HomeItem>()
    private val uiHandler = Handler(Looper.getMainLooper())
    private val smooth = PathInterpolator(0.25f, 0.1f, 0.25f, 1f)

    private var cascadePlayed = false
    private var drawerListReady = false
    private var rebuildQueued = false
    private var revealed = false
    private var bgReady = true
    private var homeReady = false
    private var idleDone = false
    private var pendingWidgetId = -1
    private var pendingProvider: AppWidgetProviderInfo? = null

    // Animasi header & dock: berkala (diam di antaranya), hanya saat launcher terlihat
    private val glowCycle = object : Runnable {
        override fun run() {
            playHeaderGlow()
            uiHandler.postDelayed(this, 4400)
        }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveBackground(uri)
    }

    // Daftar aplikasi diperbarui otomatis saat ada aplikasi dipasang / dicopot / diperbarui
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            // Saat aplikasi diperbarui, "dicopot" hanya sesaat: abaikan agar susunan halaman tidak hilang
            if (intent?.action == Intent.ACTION_PACKAGE_REMOVED &&
                intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)
            ) return
            refreshApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("hf_launcher", MODE_PRIVATE)
        IconLoader.init(this, dp(52f))

        search = findViewById(R.id.search)
        grid = findViewById(R.id.app_grid)
        homeCanvas = findViewById(R.id.home_canvas)
        homeBody = findViewById(R.id.home_body)
        dockArea = findViewById(R.id.dock_area)

        widgetManager = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, HOST_ID)

        setupDrawer()
        setupGrid()
        setupHeader()
        setupDock()
        setupHomeCanvas()

        applyBackground()
        loadHomeItems()

        // Daftar aplikasi dibaca dari catatan terakhir (instan). Pembaruan sebenarnya jalan di latar belakang.
        val index = readAppIndex()
        if (index != null) {
            hadIndex = true
            setApps(index)
        } else {
            refreshApps() // pertama kali saja
        }

        // Geser dari bawah ke atas (mulai dari 1/3 layar bagian bawah) membuka semua aplikasi
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null || homeCanvas.isDragging || sheet.state != BottomSheetBehavior.STATE_HIDDEN) return false
                val dy = e1.y - e2.y
                val h = window.decorView.height
                if (dy > dp(70f) && velocityY < -900f && e1.y > h * 0.62f && Math.abs(e1.x - e2.x) < dy) {
                    openDrawer()
                    return true
                }
                return false
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        // Pengaman: apa pun yang terjadi, halaman tetap ditampilkan
        uiHandler.postDelayed({ tryReveal(force = true) }, 1800)
    }

    // Widget & animasi hanya aktif saat launcher terlihat (hemat baterai)
    override fun onStart() {
        super.onStart()
        try {
            widgetHost.startListening()
        } catch (_: Exception) {
        }
        for (i in 0 until homeCanvas.childCount) {
            val c = homeCanvas.getChildAt(i)
            if (c is CalendarView) c.refresh()
        }
        if (revealed) startGlow()
    }

    override fun onStop() {
        super.onStop()
        try {
            widgetHost.stopListening()
        } catch (_: Exception) {
        }
        uiHandler.removeCallbacks(glowCycle)
        findViewById<View>(R.id.logo_glow).animate().cancel()
        findViewById<View>(R.id.logo_shine).animate().cancel()
        findViewById<View>(R.id.dock_sheen).animate().cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(packageReceiver)
        } catch (_: Exception) {
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // Tombol Home ditekan saat launcher sudah terbuka: tutup laci
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            closeDrawer()
        }
    }

    // Launcher tidak boleh "keluar" saat Back ditekan
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (sheet.state != BottomSheetBehavior.STATE_HIDDEN) {
            closeDrawer()
        } else if (search.text.isNotEmpty()) {
            search.setText("")
            search.clearFocus()
            hideKeyboard()
        }
    }

    // ---------- Helper ----------

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun openPos() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(POS_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("Tidak bisa membuka HARINFOOD POS")
        }
    }

    private fun keyOf(item: AppItem): String? =
        if (item.isPos) "pos" else item.component?.flattenToString()

    private fun itemForKey(key: String): AppItem? =
        if (key == "pos") posItem
        else allApps.firstOrNull { it.component?.flattenToString() == key }

    private fun isPackageInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    // ---------- Tampil bertahap tapi serempak (tidak "acak-acakan") ----------

    // Isi halaman baru ditampilkan setelah semuanya siap, lalu muncul bersama dengan memudar halus
    private fun tryReveal(force: Boolean = false) {
        if (revealed) return
        if (!force && !(bgReady && homeReady)) return
        revealed = true

        val img = findViewById<ImageView>(R.id.bg_image)
        if (img.alpha < 1f) img.animate().alpha(1f).setDuration(260).setInterpolator(smooth).start()

        homeBody.translationY = dp(12f).toFloat()
        homeBody.animate().alpha(1f).translationY(0f).setDuration(300).setInterpolator(smooth).withLayer().start()
        dockArea.translationY = dp(24f).toFloat()
        dockArea.animate().translationY(0f).setDuration(400).setStartDelay(60).setInterpolator(smooth).start()

        uiHandler.postDelayed({ idleWork() }, 550)
    }

    // Pekerjaan berat dikerjakan SETELAH tampilan muncul, sambil menganggur
    private fun idleWork() {
        if (idleDone) return
        idleDone = true
        if (hadIndex) refreshApps()
        IconLoader.prune(allApps.map { it.iconKey }.toSet())
        IconLoader.prefetch(allApps)
        prepareDrawerList()
        startGlow()
    }

    private fun startGlow() {
        uiHandler.removeCallbacks(glowCycle)
        uiHandler.postDelayed(glowCycle, 700)
    }

    private fun queueRebuild() {
        if (rebuildQueued) return
        rebuildQueued = true
        homeCanvas.post {
            rebuildQueued = false
            rebuildHome()
        }
    }

    // ---------- Setup tampilan ----------

    private fun setupDrawer() {
        val drawer = findViewById<View>(R.id.drawer)
        val root = findViewById<View>(R.id.root)
        val header = findViewById<View>(R.id.header)

        // Tinggi laci = tinggi layar - header, supaya header tetap terlihat & bisa diketuk saat laci terbuka
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            val target = root.height - header.bottom
            val lp = drawer.layoutParams
            if (target > 0 && lp.height != target) {
                lp.height = target
                drawer.layoutParams = lp
            }
        }

        sheet = BottomSheetBehavior.from(drawer)
        sheet.isHideable = true
        sheet.skipCollapsed = true
        sheet.peekHeight = 0
        sheet.state = BottomSheetBehavior.STATE_HIDDEN
        grid.alpha = 0f

        sheet.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                when (newState) {
                    BottomSheetBehavior.STATE_HIDDEN -> {
                        search.setText("")
                        search.clearFocus()
                        hideKeyboard()
                        grid.scrollToPosition(0)
                        cascadePlayed = false
                        resetDrawerItems()
                        grid.alpha = 0f
                        applySlide(0f)
                        setSlideLayers(false)
                    }
                    BottomSheetBehavior.STATE_DRAGGING, BottomSheetBehavior.STATE_SETTLING -> {
                        setSlideLayers(true)
                        prepareDrawerList()
                    }
                    BottomSheetBehavior.STATE_EXPANDED -> setSlideLayers(false)
                }
            }

            override fun onSlide(bottomSheet: View, slideOffset: Float) {
                val o = slideOffset.coerceIn(0f, 1f)
                applySlide(o)
                if (o > 0.08f && !cascadePlayed) {
                    cascadePlayed = true
                    playDrawerCascade()
                }
            }
        })
        findViewById<View>(R.id.drawer_handle).setOnClickListener { openDrawer() }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        // Tekan tombol cari di keyboard: kalau hasilnya tinggal satu, langsung dibuka
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val result = filtered()
                if (result.size == 1) launchApp(result[0])
                hideKeyboard()
                true
            } else false
        }
    }

    // Selama laci bergerak, halaman utama dijadikan "lapisan" hardware agar skala/pudar mulus
    private fun setSlideLayers(on: Boolean) {
        val t = if (on) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE
        homeCanvas.setLayerType(t, null)
        dockArea.setLayerType(t, null)
    }

    // Halaman utama "menjauh" saat laci naik: mengecil, meredup, dock turun & memudar
    private fun applySlide(o: Float) {
        homeCanvas.scaleX = 1f - 0.08f * o
        homeCanvas.scaleY = 1f - 0.08f * o
        homeCanvas.alpha = 1f - 0.6f * o
        dockArea.translationY = o * dp(120f)
        dockArea.alpha = 1f - o
    }

    // Ikon laci muncul berurutan (kaskade) dari bawah dengan membal halus
    private fun playDrawerCascade() {
        val span = (grid.layoutManager as GridLayoutManager).spanCount
        grid.alpha = 1f
        for (i in 0 until grid.childCount) {
            val v = grid.getChildAt(i)
            val row = i / span
            val col = i % span
            v.animate().cancel()
            v.alpha = 0f
            v.scaleX = 0.7f
            v.scaleY = 0.7f
            v.translationY = dp(48f).toFloat()
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setStartDelay(row * 50L + col * 20L)
                .setDuration(420)
                .setInterpolator(OvershootInterpolator(0.9f))
                .withLayer()
                .start()
        }
        search.animate().cancel()
        search.alpha = 0f
        search.translationY = -dp(16f).toFloat()
        search.animate().alpha(1f).translationY(0f).setStartDelay(60).setDuration(360)
            .setInterpolator(smooth).start()
    }

    private fun resetDrawerItems() {
        for (i in 0 until grid.childCount) {
            val v = grid.getChildAt(i)
            v.animate().cancel()
            v.alpha = 1f
            v.scaleX = 1f
            v.scaleY = 1f
            v.translationY = 0f
        }
        search.animate().cancel()
        search.alpha = 1f
        search.translationY = 0f
    }

    private fun openDrawer() {
        prepareDrawerList()
        sheet.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun closeDrawer() {
        if (sheet.state != BottomSheetBehavior.STATE_HIDDEN) sheet.state = BottomSheetBehavior.STATE_HIDDEN
    }

    private fun setupGrid() {
        // Laci semua aplikasi: jumlah kolom menyesuaikan lebar layar (HP biasa = 5)
        adapter = AppAdapter(
            onClick = { launchApp(it) },
            onLongClick = { anchor, item -> showDrawerAppMenu(anchor, item) }
        )
        val span = (resources.configuration.screenWidthDp / 80).coerceIn(4, 6)
        grid.layoutManager = GridLayoutManager(this, span)
        grid.adapter = adapter
        grid.setHasFixedSize(true)
        grid.setItemViewCacheSize(12)
        grid.recycledViewPool.setMaxRecycledViews(0, 40)
    }

    private fun setupHeader() {
        val header = findViewById<View>(R.id.header)
        val logo = findViewById<ImageView>(R.id.logo_img)
        val box = findViewById<View>(R.id.logo_box)
        IconLoader.setSync(logo, posItem)
        box.outlineProvider = RoundOutline
        box.clipToOutline = true

        // Tekan: header mengecil sedikit lalu kembali; logo ikut "pop"
        header.pressAnim(0.97f)
        header.setOnClickListener {
            box.animate().scaleX(1.15f).scaleY(1.15f).setDuration(110).withEndAction {
                box.animate().scaleX(1f).scaleY(1f).setDuration(170).start()
            }.start()
            openPos()
        }
    }

    // Cahaya lembut berdenyut + kilau menyapu logo, lalu kilau lembut menyapu dock putih.
    // Sekali tiap ~4 detik; di antaranya diam (hemat baterai).
    private fun playHeaderGlow() {
        val glow = findViewById<View>(R.id.logo_glow)
        val shine = findViewById<View>(R.id.logo_shine)
        val sheen = findViewById<View>(R.id.dock_sheen)
        val card = findViewById<View>(R.id.dock_card)

        glow.animate().cancel()
        glow.animate().alpha(0.95f).scaleX(1.2f).scaleY(1.2f).setDuration(700).setStartDelay(0)
            .setInterpolator(smooth)
            .withEndAction {
                glow.animate().alpha(0.3f).scaleX(1f).scaleY(1f).setDuration(900).setStartDelay(0)
                    .setInterpolator(smooth).start()
            }.start()

        shine.animate().cancel()
        shine.translationX = -dp(26f).toFloat()
        shine.animate().translationX(dp(42f).toFloat()).setDuration(900).setStartDelay(250)
            .setInterpolator(smooth).start()

        sheen.animate().cancel()
        sheen.translationX = -dp(100f).toFloat()
        sheen.animate().translationX(card.width.toFloat()).setDuration(1500).setStartDelay(900)
            .setInterpolator(smooth).withLayer().start()
    }

    private fun setupDock() {
        dockViews = listOf(R.id.dock_pos, R.id.dock_1, R.id.dock_2, R.id.dock_3, R.id.dock_4)
            .map { findViewById<ImageView>(it) }
        dockViews.forEach { it.pressAnim(0.9f) }
    }

    // ---------- Halaman utama: kanvas yang bisa diatur manual ----------

    private fun setupHomeCanvas() {
        homeCanvas.cols = COLS
        homeCanvas.onEmptyLongPress = { showHomeMenu() }
        homeCanvas.onItemMenu = { showItemMenu(it) }
        homeCanvas.onItemMoved = { saveHomeItems() }
        homeCanvas.onSized = { queueRebuild() }
    }

    private fun loadHomeItems() {
        homeItems.clear()
        val raw = prefs.getString("home_items", null)
        if (raw == null) {
            migrateHome()
            return
        }
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                homeItems += HomeItem(
                    o.getString("t"), o.getString("k"),
                    o.getInt("c"), o.getInt("r"), o.getInt("w"), o.getInt("h")
                )
            }
        } catch (e: Exception) {
            homeItems.clear()
        }
    }

    // Versi lama menyimpan daftar aplikasi ("home") dan widget ("widgets") secara terpisah
    private fun migrateHome() {
        homeItems += HomeItem("c", "cal", 0, 0, 4, 2)
        var r = 2
        (prefs.getString("widgets", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }.forEach { id ->
            homeItems += HomeItem("w", id.toString(), 0, r, 4, 2)
            r += 2
        }
        var c = 0
        (prefs.getString("home", "") ?: "").split("|").filter { it.isNotBlank() }.forEach { key ->
            homeItems += HomeItem("a", key, c, r, 1, 1)
            c++
            if (c >= COLS) {
                c = 0
                r++
            }
        }
        saveHomeItems()
    }

    private fun saveHomeItems() {
        val arr = JSONArray()
        homeItems.forEach {
            arr.put(
                JSONObject().put("t", it.type).put("k", it.key)
                    .put("c", it.col).put("r", it.row).put("w", it.w).put("h", it.h)
            )
        }
        prefs.edit().putString("home_items", arr.toString()).apply()
    }

    private fun rebuildHome() {
        if (!appsLoaded || homeCanvas.width == 0 || homeCanvas.height == 0) return
        homeCanvas.removeAllViews()
        val rows = homeCanvas.rows
        val placed = mutableListOf<HomeItem>()
        for (item in homeItems.toList()) {
            item.w = item.w.coerceIn(1, COLS)
            item.h = item.h.coerceIn(1, rows)
            item.col = item.col.coerceIn(0, COLS - item.w)
            item.row = item.row.coerceIn(0, rows - item.h)
            if (placed.any { HomeGrid.overlaps(it, item) }) {
                val spot = HomeGrid.findSpot(COLS, rows, item.w, item.h, placed, item.col, item.row)
                if (spot != null) {
                    item.col = spot.first
                    item.row = spot.second
                }
            }
            val v = createItemView(item)
            if (v == null) {
                // Hanya dibuang kalau aplikasi/widget benar-benar sudah tidak ada
                val gone = when (item.type) {
                    "a" -> !isPackageInstalled(item.key.substringBefore('/'))
                    "w" -> true
                    else -> false
                }
                if (gone) {
                    homeItems.remove(item)
                    if (item.type == "w") item.key.toIntOrNull()?.let { widgetHost.deleteAppWidgetId(it) }
                    saveHomeItems()
                } else {
                    placed += item
                }
                continue
            }
            placed += item
            homeCanvas.addItem(v, item)
            if (v is AppWidgetHostView) v.post { updateWidgetSize(v) }
        }
        // Setelah tata letak selesai digambar: siap ditampilkan
        homeCanvas.post {
            homeReady = true
            tryReveal()
        }
    }

    private fun createItemView(item: HomeItem): View? = when (item.type) {
        "c" -> CalendarView(this)
        "w" -> createWidgetView(item)
        "a" -> createAppView(item)
        else -> null
    }

    private fun createAppView(item: HomeItem): View? {
        val app = itemForKey(item.key) ?: return null
        val v = LayoutInflater.from(this).inflate(R.layout.item_home_app, homeCanvas, false)
        IconLoader.setSync(v.findViewById(R.id.app_icon), app)
        v.findViewById<TextView>(R.id.app_label).text = app.label
        v.setOnClickListener { launchApp(app) }
        v.pressAnim(0.92f)
        return v
    }

    private fun createWidgetView(item: HomeItem): View? {
        val id = item.key.toIntOrNull() ?: return null
        val info = widgetManager.getAppWidgetInfo(id) ?: return null
        val hv = widgetHost.createView(this, id, info)
        hv.setAppWidget(id, info)
        // Sudut membulat agar seragam dengan tampilan launcher
        hv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(20f).toFloat())
            }
        }
        hv.clipToOutline = true
        return hv
    }

    private fun updateWidgetSize(hv: AppWidgetHostView) {
        val density = resources.displayMetrics.density
        val wDp = (hv.width / density).toInt()
        val hDp = (hv.height / density).toInt()
        try {
            hv.updateAppWidgetSize(null, wDp, hDp, wDp, hDp)
        } catch (_: Exception) {
        }
    }

    private fun removeHomeItem(item: HomeItem) {
        homeItems.remove(item)
        if (item.type == "w") item.key.toIntOrNull()?.let { widgetHost.deleteAppWidgetId(it) }
        saveHomeItems()
        rebuildHome()
    }

    // Menu benda di halaman utama (muncul setelah tekan lama lalu lepas tanpa menggeser)
    private fun showItemMenu(view: View) {
        val item = view.tag as? HomeItem ?: return
        val menu = PopupMenu(this, view)
        val app = if (item.type == "a") itemForKey(item.key) else null
        when (item.type) {
            "a" -> {
                menu.menu.add(0, 1, 0, "Lepas dari halaman utama")
                if (app != null && !app.isPos) {
                    menu.menu.add(0, 2, 1, "Info aplikasi")
                    menu.menu.add(0, 3, 2, "Copot pemasangan")
                }
            }
            "w" -> {
                menu.menu.add(0, 4, 0, "Ubah ukuran")
                menu.menu.add(0, 5, 1, "Hapus widget")
            }
            "c" -> {
                menu.menu.add(0, 4, 0, "Ubah ukuran")
                menu.menu.add(0, 6, 1, "Sembunyikan kalender")
            }
        }
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                1, 5, 6 -> removeHomeItem(item)
                2 -> app?.let { a -> openAppInfo(a) }
                3 -> app?.let { a -> uninstallApp(a) }
                4 -> showSizeDialog(item)
            }
            true
        }
        menu.show()
    }

    private fun showSizeDialog(item: HomeItem) {
        val sizes = if (item.type == "c") listOf(Pair(3, 2), Pair(4, 2), Pair(4, 3))
        else listOf(Pair(2, 1), Pair(2, 2), Pair(3, 2), Pair(4, 1), Pair(4, 2), Pair(4, 3), Pair(4, 4))
        val labels = sizes.map { "${it.first} \u00D7 ${it.second}  (kolom \u00D7 baris)" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Ubah ukuran")
            .setItems(labels) { _, which -> resizeItem(item, sizes[which].first, sizes[which].second) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun resizeItem(item: HomeItem, w: Int, h: Int) {
        val nw = w.coerceAtMost(COLS)
        val nh = h.coerceAtMost(homeCanvas.rows)
        val others = homeItems.filter { it !== item }
        val spot = HomeGrid.findSpot(COLS, homeCanvas.rows, nw, nh, others, item.col, item.row)
        if (spot == null) {
            toast("Tidak cukup ruang")
            return
        }
        item.w = nw
        item.h = nh
        item.col = spot.first
        item.row = spot.second
        saveHomeItems()
        rebuildHome()
    }

    // Menu halaman (tekan lama di area kosong)
    private fun showHomeMenu() {
        val labels = mutableListOf("Tambah aplikasi", "Tambah widget", "Ganti background")
        val hasCalendar = homeItems.any { it.type == "c" }
        if (!hasCalendar) labels += "Tambah kalender"
        AlertDialog.Builder(this)
            .setTitle("Halaman utama")
            .setItems(labels.toTypedArray()) { _, which ->
                when (which) {
                    0 -> pickApp("Tambah ke halaman utama", includePos = true) { setHomeApp(it) }
                    1 -> pickWidget()
                    2 -> showBackgroundMenu()
                    3 -> addCalendar()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun addCalendar() {
        val spot = HomeGrid.findSpot(COLS, homeCanvas.rows, 4, 2, homeItems, 0, 0)
        val spot2 = if (spot == null) HomeGrid.findSpot(COLS, homeCanvas.rows, 3, 2, homeItems, 0, 0) else null
        when {
            spot != null -> homeItems += HomeItem("c", "cal", spot.first, spot.second, 4, 2)
            spot2 != null -> homeItems += HomeItem("c", "cal", spot2.first, spot2.second, 3, 2)
            else -> {
                toast("Halaman penuh")
                return
            }
        }
        saveHomeItems()
        rebuildHome()
    }

    private fun setHomeApp(item: AppItem) {
        val key = keyOf(item) ?: return
        if (homeItems.any { it.type == "a" && it.key == key }) {
            toast("Sudah ada di halaman utama")
            return
        }
        val spot = HomeGrid.findSpot(COLS, homeCanvas.rows, 1, 1, homeItems, 0, 0)
        if (spot == null) {
            toast("Halaman penuh")
            return
        }
        homeItems += HomeItem("a", key, spot.first, spot.second, 1, 1)
        saveHomeItems()
        rebuildHome()
    }

    // ---------- Background halaman utama ----------

    private fun presetDrawable(i: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, BG_COLORS[i.coerceIn(0, BG_COLORS.size - 1)])

    // Mode "Wallpaper HP": jendela dibuat transparan agar wallpaper sistem terlihat; mode lain kembali opak
    private fun setWallpaperWindow(on: Boolean) {
        if (on) {
            window.setBackgroundDrawable(ColorDrawable(0))
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
        } else {
            window.setBackgroundDrawableResource(R.drawable.bg_splash)
            window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
        }
    }

    private fun applyBackground() {
        val img = findViewById<ImageView>(R.id.bg_image)
        val scrim = findViewById<View>(R.id.bg_scrim)
        val mode = prefs.getString("bg", "preset:0") ?: "preset:0"
        when {
            mode == "photo" -> {
                setWallpaperWindow(false)
                // Dimuat di latar belakang; layar tampil serempak setelah foto siap (tanpa melompat)
                if (!revealed) {
                    bgReady = false
                    img.alpha = 0f
                }
                thread(name = "bg") {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
                    val bmp = decodeBackgroundFile()
                    runOnUiThread { showPhoto(bmp) }
                }
            }
            mode == "wallpaper" -> {
                setWallpaperWindow(true)
                img.setImageDrawable(null) // wallpaper HP terlihat di belakang
                scrim.visibility = View.VISIBLE
            }
            else -> {
                setWallpaperWindow(false)
                val idx = mode.removePrefix("preset:").toIntOrNull() ?: 0
                img.setImageDrawable(presetDrawable(idx))
                scrim.visibility = View.GONE
            }
        }
    }

    private fun showPhoto(bmp: Bitmap?) {
        val img = findViewById<ImageView>(R.id.bg_image)
        val scrim = findViewById<View>(R.id.bg_scrim)
        if (bmp != null) {
            img.setImageBitmap(bmp)
            scrim.visibility = View.VISIBLE
        } else {
            img.setImageDrawable(presetDrawable(0))
            scrim.visibility = View.GONE
        }
        bgReady = true
        if (revealed) {
            img.alpha = 0f
            img.animate().alpha(1f).setDuration(260).setInterpolator(smooth).start()
        } else {
            tryReveal()
        }
    }

    // Foto latar didekode seukuran layar saja (bukan ukuran asli) = cepat & hemat memori
    private fun decodeBackgroundFile(): Bitmap? {
        val f = File(filesDir, "bg.jpg")
        if (!f.exists()) return null
        return try {
            val dm = resources.displayMetrics
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= dm.widthPixels && bounds.outHeight / (sample * 2) >= dm.heightPixels) {
                sample *= 2
            }
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }
    }

    private fun showBackgroundMenu() {
        val labels = BG_NAMES.toMutableList()
        labels += "Foto dari galeri..."
        labels += "Wallpaper HP"
        AlertDialog.Builder(this)
            .setTitle("Ganti background")
            .setItems(labels.toTypedArray()) { _, which ->
                when {
                    which < BG_NAMES.size -> {
                        prefs.edit().putString("bg", "preset:$which").apply()
                        applyBackground()
                    }
                    which == BG_NAMES.size -> pickImage.launch("image/*")
                    else -> {
                        prefs.edit().putString("bg", "wallpaper").apply()
                        applyBackground()
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun decodeScaled(uri: Uri): Bitmap? {
        val maxSide = 1920
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val src = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    val scale = maxSide.toFloat() / maxOf(w, h)
                    if (scale < 1f) decoder.setTargetSize((w * scale).toInt(), (h * scale).toInt())
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
            } else {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun saveBackground(uri: Uri) {
        thread {
            val bmp = decodeScaled(uri)
            if (bmp == null) {
                runOnUiThread { toast("Foto tidak bisa dibuka") }
                return@thread
            }
            try {
                FileOutputStream(File(filesDir, "bg.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                prefs.edit().putString("bg", "photo").apply()
                runOnUiThread { applyBackground() }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal menyimpan foto") }
            }
        }
    }

    private fun openAppInfo(item: AppItem) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.packageName}")))
        } catch (e: Exception) {
            toast("Tidak bisa membuka menu ini")
        }
    }

    private fun uninstallApp(item: AppItem) {
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${item.packageName}")))
        } catch (e: Exception) {
            toast("Tidak bisa membuka menu ini")
        }
    }

    // ---------- Widget ----------

    private fun widgetIcon(p: AppWidgetProviderInfo): Drawable {
        val fromWidget: Drawable? = try {
            p.loadIcon(this, resources.displayMetrics.densityDpi)
        } catch (e: Exception) {
            null
        }
        if (fromWidget != null) return fromWidget
        return try {
            packageManager.getApplicationIcon(p.provider.packageName)
        } catch (e: Exception) {
            ContextCompat.getDrawable(this, R.drawable.ic_plus)!!
        }
    }

    private fun pickWidget() {
        val pm = packageManager
        val providers = widgetManager.installedProviders
            .sortedBy { it.loadLabel(pm)?.lowercase() ?: "" }
        if (providers.isEmpty()) {
            toast("Tidak ada widget yang tersedia")
            return
        }
        val entries = providers.map { p ->
            val appLabel = try {
                pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString()
            } catch (e: Exception) {
                p.provider.packageName
            }
            AppItem(
                label = "${p.loadLabel(pm)}  \u2022  $appLabel",
                packageName = p.provider.packageName,
                component = p.provider,
                staticIcon = widgetIcon(p)
            )
        }
        AlertDialog.Builder(this)
            .setTitle("Pilih widget")
            .setAdapter(PickerAdapter(this, entries)) { _, which -> startAddWidget(providers[which]) }
            .setNegativeButton("Batal", null)
            .show()
    }

    @Suppress("DEPRECATION")
    private fun startAddWidget(p: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        if (widgetManager.bindAppWidgetIdIfAllowed(id, p.provider)) {
            configureOrFinish(id, p)
        } else {
            pendingWidgetId = id
            pendingProvider = p
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            }
            try {
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                widgetHost.deleteAppWidgetId(id)
                toast("Widget tidak bisa ditambahkan")
            }
        }
    }

    private fun configureOrFinish(id: Int, p: AppWidgetProviderInfo) {
        if (p.configure != null) {
            pendingWidgetId = id
            pendingProvider = p
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIGURE, null)
            } catch (e: Exception) {
                finishAddWidget(id)
            }
        } else {
            finishAddWidget(id)
        }
    }

    // Widget ditaruh di kotak kosong sesuai ukuran bawaannya; bisa digeser & diubah ukurannya setelah itu
    private fun finishAddWidget(id: Int) {
        val info = widgetManager.getAppWidgetInfo(id)
        if (info == null) {
            widgetHost.deleteAppWidgetId(id)
            return
        }
        val rows = homeCanvas.rows
        val wSpan = Math.ceil((info.minWidth + dp(8f)) / homeCanvas.cellWidth.toDouble()).toInt().coerceIn(1, COLS)
        val hSpan = Math.ceil((info.minHeight + dp(8f)) / homeCanvas.cellHeight.toDouble()).toInt().coerceIn(1, rows)
        var foundW = 0
        var foundH = 0
        var spot: Pair<Int, Int>? = null
        outer@ for (h in hSpan downTo 1) {
            for (w in wSpan downTo 1) {
                val s = HomeGrid.findSpot(COLS, rows, w, h, homeItems, 0, 0)
                if (s != null) {
                    spot = s
                    foundW = w
                    foundH = h
                    break@outer
                }
            }
        }
        if (spot == null) {
            widgetHost.deleteAppWidgetId(id)
            toast("Halaman penuh")
            return
        }
        homeItems += HomeItem("w", id.toString(), spot.first, spot.second, foundW, foundH)
        saveHomeItems()
        rebuildHome()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingWidgetId
        when (requestCode) {
            REQ_BIND -> {
                val p = pendingProvider
                if (resultCode == RESULT_OK && p != null && id != -1) {
                    configureOrFinish(id, p)
                } else if (id != -1) {
                    widgetHost.deleteAppWidgetId(id)
                }
            }
            REQ_CONFIGURE -> {
                if (resultCode == RESULT_OK && id != -1) {
                    finishAddWidget(id)
                } else if (id != -1) {
                    widgetHost.deleteAppWidgetId(id)
                }
            }
        }
        if (requestCode == REQ_BIND || requestCode == REQ_CONFIGURE) {
            pendingWidgetId = -1
            pendingProvider = null
        }
    }

    // ---------- Daftar aplikasi (catatan di disk + pembaruan senyap di latar belakang) ----------

    private fun readAppIndex(): List<AppEntry>? {
        val f = File(filesDir, "apps_index.json")
        if (!f.exists()) return null
        return try {
            val arr = JSONArray(f.readText())
            val out = ArrayList<AppEntry>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += AppEntry(o.getString("p"), o.getString("c"), o.getString("l"), o.getLong("s"))
            }
            out
        } catch (e: Exception) {
            null
        }
    }

    private fun writeAppIndex(list: List<AppEntry>) {
        try {
            val arr = JSONArray()
            list.forEach {
                arr.put(JSONObject().put("p", it.pkg).put("c", it.cls).put("l", it.label).put("s", it.stamp))
            }
            File(filesDir, "apps_index.json").writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    private fun setApps(entries: List<AppEntry>) {
        appEntries = entries
        val apps = entries.map { e ->
            AppItem(
                label = e.label,
                packageName = e.pkg,
                component = ComponentName(e.pkg, e.cls),
                iconKey = "${e.pkg}_${Integer.toHexString(e.cls.hashCode())}_${e.stamp}"
            )
        }.sortedBy { it.label.lowercase() }
        allApps = listOf(posItem) + apps
        appsLoaded = true
        ensureDockDefaults(apps)
        loadDockSlots()
        refreshDock()
    }

    // Query ke sistem berjalan di latar belakang. Layar hanya disentuh kalau memang ada perubahan.
    private fun refreshApps() {
        thread(name = "apps") {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val stamp = try {
                        File(ri.activityInfo.applicationInfo.sourceDir).lastModified()
                    } catch (e: Exception) {
                        0L
                    }
                    AppEntry(ri.activityInfo.packageName, ri.activityInfo.name, ri.loadLabel(pm).toString(), stamp)
                }
                .sortedBy { it.label.lowercase() }
            if (appsLoaded && list.toSet() == appEntries.toSet()) return@thread
            writeAppIndex(list)
            runOnUiThread {
                setApps(list)
                rebuildHome()
                if (drawerListReady) applyFilter()
                IconLoader.prune(allApps.map { it.iconKey }.toSet())
                IconLoader.prefetch(allApps)
            }
        }
    }

    private fun filtered(): List<AppItem> {
        val q = search.text.toString().trim()
        return if (q.isEmpty()) allApps else allApps.filter { it.label.contains(q, ignoreCase = true) }
    }

    // Daftar laci diisi saat menganggur (atau saat pertama dibuka), bukan saat peluncuran
    private fun prepareDrawerList() {
        if (drawerListReady || !appsLoaded) return
        drawerListReady = true
        applyFilter()
    }

    private fun applyFilter() {
        if (!drawerListReady) return
        adapter.submit(filtered())
    }

    private fun launchApp(item: AppItem) {
        if (item.isPos || item.component == null) {
            openPos()
            closeDrawer()
            return
        }
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = item.component
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        try {
            startActivity(intent)
            closeDrawer()
        } catch (e: Exception) {
            toast("Aplikasi tidak bisa dibuka")
        }
    }

    private fun showDrawerAppMenu(anchor: View, item: AppItem) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "Taruh di halaman utama")
        menu.menu.add(0, 2, 1, "Pasang di dock")
        if (!item.isPos) {
            menu.menu.add(0, 3, 2, "Info aplikasi")
            menu.menu.add(0, 4, 3, "Copot pemasangan")
        }
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> {
                    setHomeApp(item)
                    toast("Ditambahkan ke halaman utama")
                }
                2 -> chooseSlotFor(item)
                3 -> openAppInfo(item)
                4 -> uninstallApp(item)
            }
            true
        }
        menu.show()
    }

    // ---------- Dock (5 slot, semuanya bisa diganti) ----------

    private fun ensureDockDefaults(apps: List<AppItem>) {
        if (prefs.contains("dock2")) return
        val slots = mutableListOf("pos")
        val old = prefs.getString("dock", null)
        if (old != null) {
            // Migrasi dari versi 4 slot: POS tetap di slot pertama
            old.split("|").take(4).forEach { slots += if (it.isBlank()) "-" else it }
        } else {
            val dialer = try {
                (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage
            } catch (e: Exception) {
                null
            }
            val order = listOfNotNull(dialer) + listOf(
                "com.whatsapp", "com.android.chrome", "com.instagram.android",
                "com.google.android.youtube", "com.facebook.katana", "com.google.android.apps.photos"
            )
            for (p in order) {
                val a = apps.firstOrNull { it.packageName == p } ?: continue
                val flat = a.component!!.flattenToString()
                if (slots.size < DOCK_SLOTS && !slots.contains(flat)) slots += flat
            }
        }
        while (slots.size < DOCK_SLOTS) slots += "-"
        prefs.edit().putString("dock2", slots.take(DOCK_SLOTS).joinToString("|")).apply()
    }

    private fun loadDockSlots() {
        val parts = (prefs.getString("dock2", "") ?: "").split("|")
        for (i in 0 until DOCK_SLOTS) {
            val s = parts.getOrNull(i)
            dockSlots[i] = if (s.isNullOrBlank() || s == "-") null else s
        }
    }

    private fun saveDockSlots() {
        prefs.edit().putString("dock2", dockSlots.joinToString("|") { it ?: "-" }).apply()
    }

    private fun itemForSlot(i: Int): AppItem? {
        val key = dockSlots[i] ?: return null
        return itemForKey(key)
    }

    private fun refreshDock() {
        dockViews.forEachIndexed { i, v ->
            val item = itemForSlot(i)
            if (item != null) {
                IconLoader.setSync(v, item)
                v.contentDescription = item.label
                v.setOnClickListener { launchApp(item) }
                v.setOnLongClickListener {
                    showDockMenu(v, i)
                    true
                }
            } else {
                v.setImageResource(R.drawable.ic_add_slot)
                v.contentDescription = "Tambah aplikasi"
                v.setOnClickListener { pickApp("Pilih aplikasi untuk dock", includePos = true) { app -> setSlot(i, app) } }
                v.setOnLongClickListener(null)
            }
        }
    }

    private fun showDockMenu(anchor: View, slot: Int) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "Ganti aplikasi")
        menu.menu.add(0, 2, 1, "Kosongkan")
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> pickApp("Pilih aplikasi untuk dock", includePos = true) { app -> setSlot(slot, app) }
                2 -> {
                    dockSlots[slot] = null
                    saveDockSlots()
                    refreshDock()
                }
            }
            true
        }
        menu.show()
    }

    private fun setSlot(slot: Int, item: AppItem) {
        val key = keyOf(item) ?: return
        for (i in 0 until DOCK_SLOTS) if (dockSlots[i] == key) dockSlots[i] = null
        dockSlots[slot] = key
        saveDockSlots()
        refreshDock()
    }

    private fun chooseSlotFor(item: AppItem) {
        val labels = Array(DOCK_SLOTS) { "Slot ${it + 1}: ${itemForSlot(it)?.label ?: "kosong"}" }
        AlertDialog.Builder(this)
            .setTitle("Pasang di slot dock")
            .setItems(labels) { _, which -> setSlot(which, item) }
            .setNegativeButton("Batal", null)
            .show()
    }

    // Dialog pilih aplikasi (HARINFOOD POS & aplikasi populer tampil paling atas)
    private fun pickApp(title: String, includePos: Boolean = false, onPick: (AppItem) -> Unit) {
        val popularIdx = POPULAR.withIndex().associate { it.value to it.index }
        val candidates = allApps.filter { includePos || !it.isPos }.sortedWith(
            compareBy<AppItem>(
                { if (it.isPos) -1 else (popularIdx[it.packageName] ?: Int.MAX_VALUE) },
                { it.label.lowercase() }
            )
        )
        AlertDialog.Builder(this)
            .setTitle(title)
            .setAdapter(PickerAdapter(this, candidates)) { _, which -> onPick(candidates[which]) }
            .setNegativeButton("Batal", null)
            .show()
    }
}
