package com.harinfood.launcher

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    companion object {
        const val POS_URL = "https://harinfood.mra.my.id/"
        private const val DOCK_SLOTS = 4

        // Aplikasi populer: muncul paling atas di daftar pilihan dock
        private val POPULAR = listOf(
            "com.whatsapp", "com.whatsapp.w4b", "com.instagram.android", "com.facebook.katana",
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.google.android.youtube",
            "com.android.chrome", "org.telegram.messenger", "com.google.android.apps.maps",
            "com.shopee.id", "com.tokopedia.tkpd", "com.gojek.app", "com.grabtaxi.passenger",
            "id.dana", "com.spotify.music", "com.twitter.android", "com.google.android.gm",
            "com.google.android.apps.photos", "com.android.vending"
        )
    }

    private var allApps: List<AppItem> = emptyList()
    private lateinit var adapter: AppAdapter
    private lateinit var search: EditText
    private lateinit var grid: RecyclerView
    private lateinit var prefs: SharedPreferences
    private lateinit var dockViews: List<ImageView>
    private val dockSlots = MutableList<String?>(DOCK_SLOTS) { null }

    // Daftar aplikasi dimuat ulang otomatis saat ada aplikasi dipasang / dicopot / diperbarui
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("hf_launcher", MODE_PRIVATE)

        search = findViewById(R.id.search)
        grid = findViewById(R.id.app_grid)

        adapter = AppAdapter(
            onClick = { launchApp(it) },
            onLongClick = { anchor, item -> showAppMenu(anchor, item) }
        )
        // Jumlah kolom menyesuaikan lebar layar (HP biasa = 5 kolom)
        val span = (resources.configuration.screenWidthDp / 80).coerceIn(4, 6)
        grid.layoutManager = GridLayoutManager(this, span)
        grid.adapter = adapter
        grid.setHasFixedSize(true)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        // Tekan tombol cari di keyboard: kalau hasilnya tinggal satu, langsung dibuka
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val result = filtered()
                if (result.size == 1) launchApp(result[0])
                hideKeyboard()
                true
            } else false
        }

        // Logo & header: statis (tanpa animasi berulang) agar hemat baterai. Ketuk = buka POS
        val logo = findViewById<ImageView>(R.id.logo_img)
        logo.setImageDrawable(posIcon(56))
        logo.outlineProvider = RoundOutline
        logo.elevation = resources.displayMetrics.density * 2f
        findViewById<View>(R.id.header).setOnClickListener { openPos() }

        dockViews = listOf(R.id.dock_1, R.id.dock_2, R.id.dock_3, R.id.dock_4)
            .map { findViewById<ImageView>(it) }
        val dockPos = findViewById<ImageView>(R.id.dock_pos)
        dockPos.setImageDrawable(posIcon(48))
        dockPos.setOnClickListener { openPos() }
        (dockViews + dockPos).forEach {
            it.outlineProvider = RoundOutline
            it.elevation = resources.displayMetrics.density * 1.5f
        }

        loadApps()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(packageReceiver)
        } catch (_: Exception) {
        }
    }

    // Tombol Home ditekan saat launcher sudah terbuka: kembali ke posisi awal
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            search.setText("")
            search.clearFocus()
            hideKeyboard()
            grid.scrollToPosition(0)
        }
    }

    // Launcher tidak boleh "keluar" saat Back ditekan
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (search.text.isNotEmpty()) {
            search.setText("")
            search.clearFocus()
            hideKeyboard()
        }
    }

    // ---------- Helper ----------

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()

    private fun posIcon(sizeDp: Int): android.graphics.drawable.Drawable {
        val src = ContextCompat.getDrawable(this, R.drawable.logo_harinfood)!!
        return IconRenderer.render(this, src, dp(sizeDp.toFloat()), fullBleed = true)
    }

    private fun openPos() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(POS_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membuka HARINFOOD POS", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Daftar aplikasi ----------

    private fun loadApps() {
        thread {
            val pm = packageManager
            val iconPx = dp(52f)
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppItem(
                        label = it.loadLabel(pm).toString(),
                        packageName = it.activityInfo.packageName,
                        component = ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                        icon = IconRenderer.render(this, it.loadIcon(pm), iconPx)
                    )
                }
                .sortedBy { it.label.lowercase() }
            val pos = AppItem(
                label = "HARINFOOD POS",
                packageName = "",
                component = null,
                icon = posIcon(52),
                isPos = true
            )
            val list = listOf(pos) + apps
            runOnUiThread {
                allApps = list
                ensureDockDefaults(apps)
                loadDockSlots()
                refreshDock()
                applyFilter()
            }
        }
    }

    private fun filtered(): List<AppItem> {
        val q = search.text.toString().trim()
        return if (q.isEmpty()) allApps else allApps.filter { it.label.contains(q, ignoreCase = true) }
    }

    private fun applyFilter() {
        adapter.submit(filtered())
    }

    private fun launchApp(item: AppItem) {
        if (item.isPos || item.component == null) {
            openPos()
            return
        }
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = item.component
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Aplikasi tidak bisa dibuka", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppMenu(anchor: View, item: AppItem) {
        if (item.isPos) return
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "Pasang di dock")
        menu.menu.add(0, 2, 1, "Info aplikasi")
        menu.menu.add(0, 3, 2, "Copot pemasangan")
        menu.setOnMenuItemClickListener {
            val uri = Uri.parse("package:${item.packageName}")
            try {
                when (it.itemId) {
                    1 -> chooseSlotFor(item)
                    2 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    3 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak bisa membuka menu ini", Toast.LENGTH_SHORT).show()
            }
            true
        }
        menu.show()
    }

    // ---------- Dock (bisa diganti aplikasi populer) ----------
    // Slot paling kiri = HARINFOOD POS (tetap). 4 slot lain bebas diganti.

    private fun ensureDockDefaults(apps: List<AppItem>) {
        if (prefs.contains("dock")) return
        val dialer = try {
            (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage
        } catch (e: Exception) {
            null
        }
        val order = listOfNotNull(dialer) + listOf(
            "com.whatsapp", "com.android.chrome", "com.instagram.android",
            "com.google.android.youtube", "com.facebook.katana", "com.google.android.apps.photos"
        )
        val picked = mutableListOf<String>()
        for (p in order) {
            val a = apps.firstOrNull { it.packageName == p } ?: continue
            val flat = a.component!!.flattenToString()
            if (picked.size < DOCK_SLOTS && !picked.contains(flat)) picked += flat
        }
        while (picked.size < DOCK_SLOTS) picked += "-"
        prefs.edit().putString("dock", picked.joinToString("|")).apply()
    }

    private fun loadDockSlots() {
        val parts = (prefs.getString("dock", "") ?: "").split("|")
        for (i in 0 until DOCK_SLOTS) {
            val s = parts.getOrNull(i)
            dockSlots[i] = if (s.isNullOrBlank() || s == "-") null else s
        }
    }

    private fun saveDockSlots() {
        prefs.edit().putString("dock", dockSlots.joinToString("|") { it ?: "-" }).apply()
    }

    private fun itemForSlot(i: Int): AppItem? {
        val flat = dockSlots[i] ?: return null
        return allApps.firstOrNull { it.component?.flattenToString() == flat }
    }

    private fun refreshDock() {
        dockViews.forEachIndexed { i, v ->
            val item = itemForSlot(i)
            if (item != null) {
                v.setImageDrawable(item.icon)
                v.contentDescription = item.label
                v.setOnClickListener { launchApp(item) }
                v.setOnLongClickListener {
                    showDockMenu(v, i)
                    true
                }
            } else {
                v.setImageResource(R.drawable.ic_add_slot)
                v.contentDescription = "Tambah aplikasi"
                v.setOnClickListener { pickAppForSlot(i) }
                v.setOnLongClickListener(null)
            }
        }
    }

    private fun showDockMenu(anchor: View, slot: Int) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "Ganti aplikasi")
        menu.menu.add(0, 2, 1, "Kosongkan")
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> pickAppForSlot(slot)
                2 -> {
                    dockSlots[slot] = null
                    saveDockSlots()
                    refreshDock()
                }
            }
            true
        }
        menu.show()
    }

    private fun setSlot(slot: Int, item: AppItem) {
        val flat = item.component?.flattenToString() ?: return
        for (i in 0 until DOCK_SLOTS) if (dockSlots[i] == flat) dockSlots[i] = null
        dockSlots[slot] = flat
        saveDockSlots()
        refreshDock()
    }

    private fun chooseSlotFor(item: AppItem) {
        val labels = Array(DOCK_SLOTS) { "Slot ${it + 1}: ${itemForSlot(it)?.label ?: "kosong"}" }
        AlertDialog.Builder(this)
            .setTitle("Pasang di slot dock")
            .setItems(labels) { _, which -> setSlot(which, item) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun pickAppForSlot(slot: Int) {
        val popularIdx = POPULAR.withIndex().associate { it.value to it.index }
        val candidates = allApps.filter { !it.isPos }.sortedWith(
            compareBy<AppItem>({ popularIdx[it.packageName] ?: Int.MAX_VALUE }, { it.label.lowercase() })
        )
        AlertDialog.Builder(this)
            .setTitle("Pilih aplikasi untuk dock")
            .setAdapter(PickerAdapter(this, candidates)) { _, which -> setSlot(slot, candidates[which]) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
    }
}
