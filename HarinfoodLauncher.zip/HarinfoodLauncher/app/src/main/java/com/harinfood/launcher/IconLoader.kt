package com.harinfood.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * Ikon dibuat SEKALI lalu disimpan di disk (cache). Pembukaan berikutnya cukup membaca berkas kecil,
 * sehingga launcher langsung tampil rapi tanpa menggambar ulang ratusan ikon.
 * - Halaman utama & dock: langsung (sinkron) dari cache = tidak ada ikon yang "muncul acak".
 * - Laci aplikasi: dimuat malas di latar belakang dengan kotak penampung yang sudah berukuran tepat.
 */
object IconLoader {

    private lateinit var appCtx: Context
    private lateinit var dir: File
    private var sizePx = 0
    private val main = Handler(Looper.getMainLooper())
    private val visibleExec = Executors.newFixedThreadPool(2)
    private val prefetchExec = Executors.newSingleThreadExecutor()

    private val mem = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 12).toInt().coerceAtLeast(2 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun init(ctx: Context, sizePx: Int) {
        if (::appCtx.isInitialized && this.sizePx == sizePx) return
        appCtx = ctx.applicationContext
        this.sizePx = sizePx
        dir = File(appCtx.filesDir, "icons").apply { mkdirs() }
    }

    private fun fromDisk(key: String): Bitmap? {
        val f = File(dir, "$key.png")
        if (!f.exists()) return null
        val b = BitmapFactory.decodeFile(f.path) ?: return null
        mem.put(key, b)
        return b
    }

    private fun render(item: AppItem): Bitmap? {
        val src: Drawable = try {
            if (item.isPos) ContextCompat.getDrawable(appCtx, R.drawable.logo_harinfood)
            else appCtx.packageManager.getActivityIcon(item.component!!)
        } catch (e: Exception) {
            null
        } ?: return null
        val bmp = IconRenderer.render(appCtx, src, sizePx, fullBleed = item.isPos)
        val key = item.iconKey
        mem.put(key, bmp)
        try {
            FileOutputStream(File(dir, "$key.png")).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {
        }
        return bmp
    }

    /** Ambil bitmap: memori -> disk -> gambar baru (hanya sekali seumur ikon). */
    fun bitmapSync(item: AppItem): Bitmap? {
        val key = item.iconKey
        return mem.get(key) ?: fromDisk(key) ?: render(item)
    }

    /** Tampilkan langsung (untuk halaman utama & dock yang jumlahnya sedikit). */
    fun setSync(view: ImageView, item: AppItem) {
        val staticIcon = item.staticIcon
        if (staticIcon != null) {
            view.setImageDrawable(staticIcon)
            return
        }
        val b = bitmapSync(item)
        if (b != null) view.setImageBitmap(b) else view.setImageResource(R.drawable.bg_icon_placeholder)
    }

    /** Tampilkan malas (laci & dialog): kotak penampung dulu, ikon menyusul dengan memudar halus. */
    fun load(view: ImageView, item: AppItem) {
        view.animate().cancel()
        view.alpha = 1f
        val staticIcon = item.staticIcon
        if (staticIcon != null) {
            view.tag = null
            view.setImageDrawable(staticIcon)
            return
        }
        val key = item.iconKey
        view.tag = key
        val hit = mem.get(key)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        view.setImageResource(R.drawable.bg_icon_placeholder)
        visibleExec.execute {
            val b = bitmapSync(item) ?: return@execute
            main.post {
                if (view.tag == key) {
                    view.alpha = 0f
                    view.setImageBitmap(b)
                    view.animate().alpha(1f).setDuration(140).start()
                }
            }
        }
    }

    /** Siapkan semua ikon di latar belakang agar laci langsung penuh saat dibuka. */
    fun prefetch(items: List<AppItem>) {
        val copy = items.toList()
        prefetchExec.execute { copy.forEach { if (it.staticIcon == null) bitmapSync(it) } }
    }

    /** Hapus berkas ikon aplikasi yang sudah tidak ada / sudah diperbarui. */
    fun prune(validKeys: Set<String>) {
        prefetchExec.execute {
            dir.listFiles()?.forEach { if (it.nameWithoutExtension !in validKeys) it.delete() }
        }
    }
}
