# View yang dibuat lewat XML
-keep class com.harinfood.launcher.HomeCanvas { <init>(...); }
-keep class com.harinfood.launcher.CalendarView { <init>(...); }
-keepattributes *Annotation*
